# 📁 PETMS Complete File Structure

## 🎯 Project Overview

This document provides a complete, detailed file structure for the PETMS (Public Expenditure Transparency & Monitoring System) project, including both frontend and backend with identical organizational patterns.

---

## 🗂️ Root Project Structure

```
petms/
├── frontend/                  # React application
├── backend/                   # Node.js API server
├── .gitignore                # Git ignore rules
├── README.md                 # Main project README
├── LICENSE                   # MIT License
└── docs/                     # Additional documentation
    ├── API.md                # API documentation
    ├── DEPLOYMENT.md         # Deployment guide
    └── ARCHITECTURE.md       # System architecture
```

---

## 🎨 Frontend Structure (Complete)

```
frontend/
├── public/
│   ├── index.html
│   ├── favicon.ico
│   ├── manifest.json
│   ├── robots.txt
│   ├── markers/                      # Map marker icons
│   │   ├── green-marker.png
│   │   ├── yellow-marker.png
│   │   └── red-marker.png
│   └── assets/
│       ├── logo-admin.png
│       ├── logo-contractor.png
│       └── logo-citizen.png
│
├── src/
│   ├── assets/
│   │   ├── images/
│   │   │   ├── hero-bg.jpg
│   │   │   ├── login-bg.jpg
│   │   │   └── placeholder.png
│   │   ├── icons/
│   │   │   ├── admin-icon.svg
│   │   │   ├── contractor-icon.svg
│   │   │   └── citizen-icon.svg
│   │   └── fonts/
│   │       └── Inter-var.woff2
│   │
│   ├── components/
│   │   ├── common/                   # Shared components
│   │   │   ├── Button.jsx
│   │   │   ├── Card.jsx
│   │   │   ├── Badge.jsx
│   │   │   ├── Input.jsx
│   │   │   ├── FormInput.jsx
│   │   │   ├── Select.jsx
│   │   │   ├── Textarea.jsx
│   │   │   ├── Checkbox.jsx
│   │   │   ├── Modal.jsx
│   │   │   ├── Dialog.jsx
│   │   │   ├── Alert.jsx
│   │   │   ├── Toast.jsx
│   │   │   ├── Loader.jsx
│   │   │   ├── Spinner.jsx
│   │   │   ├── Skeleton.jsx
│   │   │   ├── StatsCard.jsx
│   │   │   ├── ProgressBar.jsx
│   │   │   ├── Pagination.jsx
│   │   │   ├── SearchBar.jsx
│   │   │   ├── FilterPanel.jsx
│   │   │   ├── ProjectMap.jsx
│   │   │   ├── MapMarker.jsx
│   │   │   ├── ProtectedRoute.jsx
│   │   │   └── ErrorBoundary.jsx
│   │   │
│   │   ├── layout/                   # Layout components
│   │   │   ├── AdminSidebar.jsx
│   │   │   ├── ContractorSidebar.jsx
│   │   │   ├── CitizenNavbar.jsx
│   │   │   ├── Header.jsx
│   │   │   ├── Footer.jsx
│   │   │   ├── Breadcrumb.jsx
│   │   │   └── MobileMenu.jsx
│   │   │
│   │   ├── admin/                    # Admin-specific
│   │   │   ├── ProjectsTable.jsx
│   │   │   ├── ProjectRow.jsx
│   │   │   ├── AddProjectForm.jsx
│   │   │   ├── EditProjectForm.jsx
│   │   │   ├── AnalyticsCharts.jsx
│   │   │   ├── BudgetPieChart.jsx
│   │   │   ├── SpendingBarChart.jsx
│   │   │   ├── MonthlyTrendsChart.jsx
│   │   │   ├── RiskAlertsPanel.jsx
│   │   │   ├── AlertItem.jsx
│   │   │   ├── ComplaintsTable.jsx
│   │   │   ├── ComplaintDetails.jsx
│   │   │   ├── RespondToComplaint.jsx
│   │   │   └── DepartmentStats.jsx
│   │   │
│   │   ├── contractor/               # Contractor-specific
│   │   │   ├── ProjectCard.jsx
│   │   │   ├── ProjectGrid.jsx
│   │   │   ├── ProgressUpdateForm.jsx
│   │   │   ├── PhotoUploader.jsx
│   │   │   ├── GPSValidator.jsx
│   │   │   ├── UpdatesTimeline.jsx
│   │   │   ├── TimelineItem.jsx
│   │   │   ├── PaymentStatus.jsx
│   │   │   ├── TrancheTable.jsx
│   │   │   └── MyProjectStats.jsx
│   │   │
│   │   └── citizen/                  # Citizen-specific
│   │       ├── ProjectGallery.jsx
│   │       ├── ProjectCard.jsx
│   │       ├── ProjectDetailsModal.jsx
│   │       ├── ProjectInfo.jsx
│   │       ├── BudgetBreakdown.jsx
│   │       ├── TimelineProgress.jsx
│   │       ├── ComplaintForm.jsx
│   │       ├── ComplaintSubmit.jsx
│   │       ├── MyComplaints.jsx
│   │       ├── ComplaintCard.jsx
│   │       ├── UpvoteButton.jsx
│   │       ├── SocialFeed.jsx
│   │       ├── FeedItem.jsx
│   │       ├── CommentSection.jsx
│   │       └── FilterSidebar.jsx
│   │
│   ├── pages/
│   │   ├── auth/
│   │   │   ├── AdminLogin.jsx
│   │   │   ├── ContractorLogin.jsx
│   │   │   ├── CitizenLogin.jsx
│   │   │   ├── Register.jsx
│   │   │   └── ForgotPassword.jsx
│   │   │
│   │   ├── admin/
│   │   │   ├── AdminDashboard.jsx
│   │   │   ├── AdminProjects.jsx
│   │   │   ├── AdminProjectDetails.jsx
│   │   │   ├── AdminAddProject.jsx
│   │   │   ├── AdminEditProject.jsx
│   │   │   ├── AdminComplaints.jsx
│   │   │   ├── AdminComplaintDetails.jsx
│   │   │   ├── AdminAnalytics.jsx
│   │   │   └── AdminSettings.jsx
│   │   │
│   │   ├── contractor/
│   │   │   ├── ContractorDashboard.jsx
│   │   │   ├── ContractorProjects.jsx
│   │   │   ├── ContractorProjectDetails.jsx
│   │   │   ├── ContractorUpdateProgress.jsx
│   │   │   ├── ContractorReports.jsx
│   │   │   └── ContractorProfile.jsx
│   │   │
│   │   ├── citizen/
│   │   │   ├── CitizenDashboard.jsx
│   │   │   ├── CitizenProjects.jsx
│   │   │   ├── CitizenProjectDetails.jsx
│   │   │   ├── CitizenMapView.jsx
│   │   │   ├── CitizenComplaints.jsx
│   │   │   ├── CitizenComplaintDetails.jsx
│   │   │   ├── CitizenSubmitComplaint.jsx
│   │   │   └── CitizenProfile.jsx
│   │   │
│   │   ├── NotFound.jsx
│   │   └── Unauthorized.jsx
│   │
│   ├── hooks/                        # Custom React hooks
│   │   ├── useAuth.js
│   │   ├── useProject.js
│   │   ├── useComplaint.js
│   │   ├── useStats.js
│   │   ├── useMap.js
│   │   ├── useDebounce.js
│   │   ├── useLocalStorage.js
│   │   ├── useMediaQuery.js
│   │   ├── useIntersectionObserver.js
│   │   └── useFileUpload.js
│   │
│   ├── utils/                        # Helper functions
│   │   ├── formatters.js             # Currency, date formatting
│   │   │   ├── formatCurrency()
│   │   │   ├── formatDate()
│   │   │   ├── formatRelativeTime()
│   │   │   ├── getPercentageColor()
│   │   │   └── getStatusBadgeColor()
│   │   │
│   │   ├── validators.js             # Form validation
│   │   │   ├── isValidEmail()
│   │   │   ├── isValidPassword()
│   │   │   ├── isValidPhone()
│   │   │   ├── isValidPincode()
│   │   │   ├── isValidImage()
│   │   │   └── validateForm()
│   │   │
│   │   ├── gps.utils.js              # GPS calculations
│   │   │   ├── calculateDistance()
│   │   │   ├── extractGPSFromFile()
│   │   │   └── validateGPSLocation()
│   │   │
│   │   ├── constants.js              # App constants
│   │   │   ├── DEPARTMENTS[]
│   │   │   ├── PROJECT_STATUS{}
│   │   │   ├── COMPLAINT_STATUS{}
│   │   │   ├── USER_ROLES{}
│   │   │   ├── RISK_THRESHOLDS{}
│   │   │   ├── INDIAN_STATES[]
│   │   │   └── CHART_COLORS{}
│   │   │
│   │   ├── api.helpers.js            # API helper functions
│   │   └── storage.js                # LocalStorage helpers
│   │
│   ├── services/                     # API integration
│   │   ├── api.js                    # Axios instance
│   │   ├── auth.service.js
│   │   │   ├── login()
│   │   │   ├── register()
│   │   │   ├── logout()
│   │   │   └── getCurrentUser()
│   │   │
│   │   ├── project.service.js
│   │   │   ├── getProjects()
│   │   │   ├── getProjectById()
│   │   │   ├── createProject()
│   │   │   ├── updateProject()
│   │   │   ├── deleteProject()
│   │   │   └── getNearbyProjects()
│   │   │
│   │   ├── complaint.service.js
│   │   │   ├── getComplaints()
│   │   │   ├── getComplaintById()
│   │   │   ├── submitComplaint()
│   │   │   ├── upvoteComplaint()
│   │   │   └── respondToComplaint()
│   │   │
│   │   ├── stats.service.js
│   │   │   ├── getOverviewStats()
│   │   │   ├── getDepartmentAllocation()
│   │   │   ├── getMonthlyTrends()
│   │   │   └── getContractorStats()
│   │   │
│   │   └── upload.service.js
│   │       ├── uploadImage()
│   │       └── uploadMultipleImages()
│   │
│   ├── store/                        # Zustand stores
│   │   ├── authStore.js
│   │   │   ├── user
│   │   │   ├── isAuthenticated
│   │   │   ├── role
│   │   │   ├── login()
│   │   │   ├── logout()
│   │   │   └── updateUser()
│   │   │
│   │   ├── projectStore.js
│   │   │   ├── projects[]
│   │   │   ├── selectedProject
│   │   │   ├── filters{}
│   │   │   ├── fetchProjects()
│   │   │   └── setFilters()
│   │   │
│   │   ├── complaintStore.js
│   │   │   ├── complaints[]
│   │   │   ├── selectedComplaint
│   │   │   └── fetchComplaints()
│   │   │
│   │   └── uiStore.js
│   │       ├── isSidebarOpen
│   │       ├── theme
│   │       └── toggleSidebar()
│   │
│   ├── config/                       # Configuration
│   │   ├── routes.js                 # Route definitions
│   │   ├── map.config.js             # Map settings
│   │   └── theme.config.js           # Theme colors
│   │
│   ├── styles/                       # CSS files
│   │   ├── index.css                 # Tailwind imports
│   │   ├── globals.css               # Global styles
│   │   └── components.css            # Component styles
│   │
│   ├── App.jsx                       # Root component
│   ├── main.jsx                      # Entry point
│   └── vite-env.d.ts                 # Vite types
│
├── .env.example                      # Environment template
├── .env                              # Environment variables (gitignored)
├── .gitignore
├── .eslintrc.json                    # ESLint config
├── .prettierrc                       # Prettier config
├── index.html
├── package.json
├── package-lock.json
├── vite.config.js
├── tailwind.config.js
├── postcss.config.js
└── README.md
```

---

## ⚙️ Backend Structure (Complete)

```
backend/
├── src/
│   ├── config/
│   │   ├── database.js               # MongoDB connection
│   │   │   ├── connectDB()
│   │   │   └── connection events
│   │   │
│   │   ├── cloudinary.js             # Cloudinary setup
│   │   │   ├── cloudinary.config()
│   │   │   ├── uploadToCloudinary()
│   │   │   └── deleteFromCloudinary()
│   │   │
│   │   ├── constants.js              # App constants
│   │   │   ├── ROLES{}
│   │   │   ├── PROJECT_STATUS{}
│   │   │   ├── COMPLAINT_STATUS{}
│   │   │   ├── DEPARTMENTS[]
│   │   │   ├── RED_FLAG_THRESHOLDS{}
│   │   │   └── FILE_LIMITS{}
│   │   │
│   │   └── env.js                    # Environment validation
│   │
│   ├── models/                       # Mongoose schemas
│   │   ├── User.js
│   │   │   ├── Schema definition
│   │   │   ├── Pre-save hooks
│   │   │   ├── comparePassword()
│   │   │   └── generateToken()
│   │   │
│   │   ├── Project.js
│   │   │   ├── Schema definition
│   │   │   ├── Virtuals (delayDays, spendingPercentage)
│   │   │   └── Indexes (geospatial)
│   │   │
│   │   ├── Complaint.js
│   │   │   ├── Schema definition
│   │   │   ├── Pre-save hooks (tracking ID)
│   │   │   └── Auto-flagging logic
│   │   │
│   │   └── Update.js
│   │       ├── Schema definition
│   │       └── GPS validation fields
│   │
│   ├── routes/                       # API routes
│   │   ├── auth.routes.js
│   │   │   ├── POST /register
│   │   │   ├── POST /login
│   │   │   ├── GET /me
│   │   │   └── POST /logout
│   │   │
│   │   ├── project.routes.js
│   │   │   ├── GET /
│   │   │   ├── GET /:id
│   │   │   ├── POST /
│   │   │   ├── PUT /:id
│   │   │   ├── DELETE /:id
│   │   │   └── GET /nearby
│   │   │
│   │   ├── complaint.routes.js
│   │   │   ├── GET /
│   │   │   ├── GET /:id
│   │   │   ├── POST /
│   │   │   ├── POST /:id/upvote
│   │   │   └── PUT /:id/respond
│   │   │
│   │   └── stats.routes.js
│   │       ├── GET /overview
│   │       ├── GET /department-allocation
│   │       ├── GET /monthly-trends
│   │       └── GET /contractor
│   │
│   ├── controllers/                  # Business logic
│   │   ├── auth.controller.js
│   │   │   ├── register()
│   │   │   ├── login()
│   │   │   ├── getMe()
│   │   │   └── logout()
│   │   │
│   │   ├── project.controller.js
│   │   │   ├── getAllProjects()
│   │   │   ├── getProject()
│   │   │   ├── createProject()
│   │   │   ├── updateProject()
│   │   │   ├── deleteProject()
│   │   │   └── getNearbyProjects()
│   │   │
│   │   ├── complaint.controller.js
│   │   │   ├── submitComplaint()
│   │   │   ├── getAllComplaints()
│   │   │   ├── getComplaint()
│   │   │   ├── upvoteComplaint()
│   │   │   └── respondToComplaint()
│   │   │
│   │   └── stats.controller.js
│   │       ├── getOverviewStats()
│   │       ├── getDepartmentAllocation()
│   │       ├── getMonthlyTrends()
│   │       └── getContractorStats()
│   │
│   ├── middleware/                   # Custom middleware
│   │   ├── auth.middleware.js
│   │   │   ├── protect()            # JWT verification
│   │   │   └── authorize()          # Role checking
│   │   │
│   │   ├── upload.middleware.js
│   │   │   ├── uploadSingle
│   │   │   ├── uploadMultiple
│   │   │   └── handleUploadError()
│   │   │
│   │   ├── validate.middleware.js
│   │   │   ├── validateInput()
│   │   │   └── handleValidationErrors()
│   │   │
│   │   ├── error.middleware.js
│   │   │   └── errorHandler()
│   │   │
│   │   └── role.middleware.js
│   │       ├── isAdmin()
│   │       ├── isContractor()
│   │       └── isCitizen()
│   │
│   ├── utils/                        # Helper functions
│   │   ├── redFlag.utils.js
│   │   │   ├── calculateRiskFlag()
│   │   │   ├── calculateDelayDays()
│   │   │   ├── generateRiskMessage()
│   │   │   └── getRiskSeverity()
│   │   │
│   │   ├── gps.utils.js
│   │   │   ├── extractGPSFromImage()
│   │   │   ├── calculateDistance()
│   │   │   ├── validateGPSLocation()
│   │   │   └── processAndValidateImages()
│   │   │
│   │   ├── email.utils.js
│   │   │   ├── sendEmail()
│   │   │   └── sendAlertEmail()
│   │   │
│   │   └── response.utils.js
│   │       ├── successResponse()
│   │       └── errorResponse()
│   │
│   ├── jobs/                         # Cron jobs
│   │   └── redFlag.job.js
│   │       ├── redFlagScanJob
│   │       ├── startRedFlagJob()
│   │       └── stopRedFlagJob()
│   │
│   ├── validators/                   # Request validators
│   │   ├── auth.validator.js
│   │   │   ├── validateRegister[]
│   │   │   └── validateLogin[]
│   │   │
│   │   ├── project.validator.js
│   │   │   ├── validateCreateProject[]
│   │   │   └── validateUpdateProject[]
│   │   │
│   │   └── complaint.validator.js
│   │       └── validateComplaint[]
│   │
│   ├── app.js                        # Express app setup
│   │   ├── Middleware configuration
│   │   ├── Route mounting
│   │   ├── Error handling
│   │   └── 404 handler
│   │
│   └── server.js                     # Server entry point
│       ├── Environment setup
│       ├── Database connection
│       ├── Server start
│       ├── Cron job start
│       └── Graceful shutdown
│
├── scripts/
│   ├── seed.js                       # Database seeding
│   │   ├── seedUsers()
│   │   ├── seedProjects()
│   │   └── seedComplaints()
│   │
│   └── backup.js                     # Database backup
│
├── uploads/                          # Temporary file storage
│   ├── .gitkeep
│   └── (uploaded files - gitignored)
│
├── tests/                            # Test files (optional)
│   ├── unit/
│   ├── integration/
│   └── e2e/
│
├── .env.example                      # Environment template
├── .env                              # Environment variables (gitignored)
├── .gitignore
├── .eslintrc.json
├── package.json
├── package-lock.json
└── README.md
```

---

## 📊 File Count Summary

### Frontend
- **Total Files**: ~120
  - Components: ~60
  - Pages: ~25
  - Hooks: ~10
  - Utils: ~8
  - Services: ~6
  - Stores: ~4
  - Config: ~7

### Backend
- **Total Files**: ~35
  - Models: 4
  - Routes: 4
  - Controllers: 4
  - Middleware: 5
  - Utils: 4
  - Validators: 3
  - Jobs: 1
  - Scripts: 2
  - Config: 4

### Total Project
- **~155 core files**
- **Plus**: Package files, configs, documentation

---

## 🎯 Key Directories Explained

### Frontend Key Directories

1. **`/src/components/common`**
   - Reusable UI components used across all roles
   - Example: Buttons, Cards, Modals, Form inputs

2. **`/src/components/layout`**
   - Layout components specific to each role
   - Sidebars, navigation bars, headers

3. **`/src/pages`**
   - Full page components
   - Organized by role (admin/contractor/citizen)

4. **`/src/services`**
   - API integration layer
   - One service per resource (auth, projects, complaints)

5. **`/src/store`**
   - Zustand state management
   - Global app state

### Backend Key Directories

1. **`/src/models`**
   - Mongoose schemas
   - Data validation and business logic

2. **`/src/routes`**
   - API endpoint definitions
   - Route-level middleware

3. **`/src/controllers`**
   - Request handling logic
   - Business logic execution

4. **`/src/middleware`**
   - Custom middleware functions
   - Authentication, validation, error handling

5. **`/src/utils`**
   - Helper functions
   - Red flag detection, GPS validation

---

## 🔄 File Naming Conventions

### Frontend
- Components: `PascalCase.jsx` (e.g., `ProjectCard.jsx`)
- Pages: `PascalCase.jsx` (e.g., `AdminDashboard.jsx`)
- Hooks: `camelCase.js` with `use` prefix (e.g., `useAuth.js`)
- Utils: `camelCase.js` (e.g., `formatters.js`)
- Services: `camelCase.service.js` (e.g., `auth.service.js`)
- Stores: `camelCase Store.js` (e.g., `authStore.js`)

### Backend
- Models: `PascalCase.js` (e.g., `User.js`)
- Routes: `camelCase.routes.js` (e.g., `auth.routes.js`)
- Controllers: `camelCase.controller.js` (e.g., `auth.controller.js`)
- Middleware: `camelCase.middleware.js` (e.g., `auth.middleware.js`)
- Utils: `camelCase.utils.js` (e.g., `redFlag.utils.js`)
- Validators: `camelCase.validator.js` (e.g., `auth.validator.js`)

---

## ✅ Implementation Checklist

### Frontend Setup
- [ ] Initialize Vite React project
- [ ] Install all dependencies
- [ ] Configure Tailwind CSS
- [ ] Set up Shadcn/ui
- [ ] Create folder structure
- [ ] Set up routing
- [ ] Configure Zustand stores
- [ ] Set up Axios with interceptors
- [ ] Create reusable components
- [ ] Build login pages
- [ ] Build dashboards
- [ ] Implement map integration
- [ ] Add chart components
- [ ] Test all user flows

### Backend Setup
- [ ] Initialize Node.js project
- [ ] Install all dependencies
- [ ] Configure environment variables
- [ ] Set up MongoDB connection
- [ ] Create folder structure
- [ ] Define Mongoose models
- [ ] Create API routes
- [ ] Implement controllers
- [ ] Add middleware (auth, upload, validation)
- [ ] Implement GPS validation
- [ ] Create red flag detection
- [ ] Set up cron jobs
- [ ] Add email notifications
- [ ] Create seed script
- [ ] Test all endpoints

---

This file structure ensures consistency, scalability, and maintainability across the entire PETMS project!
