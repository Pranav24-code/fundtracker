# ⚙️ PETMS Backend Development Guide

## 📋 Complete Prompting File for Backend Development

This document contains all the prompts you need to build the PETMS backend API using Node.js, Express, and MongoDB.

---

## 🎯 Initial Setup Prompt

```
Create a Node.js backend API for PETMS (Public Expenditure Transparency & Monitoring System) with the following setup:

TECH STACK:
- Node.js 18.x
- Express.js 4.x
- MongoDB with Mongoose
- JWT for authentication
- Multer for file uploads
- EXIF parser for GPS extraction
- Node-cron for scheduled tasks
- Cloudinary for image storage

PROJECT STRUCTURE:
backend/
├── src/
│   ├── config/                # Configuration files
│   │   ├── database.js        # MongoDB connection
│   │   ├── cloudinary.js      # Cloudinary setup
│   │   ├── constants.js       # App constants
│   │   └── env.js             # Environment variables
│   ├── models/                # Mongoose schemas
│   │   ├── User.js            # User model
│   │   ├── Project.js         # Project model
│   │   ├── Complaint.js       # Complaint model
│   │   └── Update.js          # Progress update model
│   ├── routes/                # API routes
│   │   ├── auth.routes.js     # Authentication endpoints
│   │   ├── project.routes.js  # Project CRUD
│   │   ├── complaint.routes.js # Complaint management
│   │   └── stats.routes.js    # Analytics endpoints
│   ├── controllers/           # Business logic
│   │   ├── auth.controller.js
│   │   ├── project.controller.js
│   │   ├── complaint.controller.js
│   │   └── stats.controller.js
│   ├── middleware/            # Custom middleware
│   │   ├── auth.middleware.js # JWT verification
│   │   ├── upload.middleware.js # File upload handling
│   │   ├── validate.middleware.js # Input validation
│   │   ├── error.middleware.js # Error handling
│   │   └── role.middleware.js # Role-based access
│   ├── utils/                 # Helper functions
│   │   ├── redFlag.utils.js   # Red flag detection
│   │   ├── gps.utils.js       # GPS validation
│   │   ├── email.utils.js     # Email notifications
│   │   └── response.utils.js  # Standardized responses
│   ├── jobs/                  # Cron jobs
│   │   └── redFlag.job.js     # Automated red flag scanning
│   ├── validators/            # Request validators
│   │   ├── auth.validator.js
│   │   ├── project.validator.js
│   │   └── complaint.validator.js
│   ├── app.js                 # Express app setup
│   └── server.js              # Server entry point
├── uploads/                   # Temporary file storage
├── .env.example               # Environment variables template
├── .gitignore
├── package.json
└── README.md

REQUIRED PACKAGES:
{
  "dependencies": {
    "express": "^4.18.2",
    "mongoose": "^8.0.0",
    "dotenv": "^16.3.1",
    "bcryptjs": "^2.4.3",
    "jsonwebtoken": "^9.0.2",
    "multer": "^1.4.5-lts.1",
    "cloudinary": "^1.41.0",
    "exif-parser": "^0.1.12",
    "node-cron": "^3.0.3",
    "cors": "^2.8.5",
    "helmet": "^7.1.0",
    "express-rate-limit": "^7.1.5",
    "express-validator": "^7.0.1",
    "nodemailer": "^6.9.7",
    "morgan": "^1.10.0"
  },
  "devDependencies": {
    "nodemon": "^3.0.2"
  }
}

ENVIRONMENT VARIABLES (.env.example):
NODE_ENV=development
PORT=5000

# Database
MONGODB_URI=mongodb://localhost:27017/petms
# or for Atlas:
# MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/petms

# JWT
JWT_SECRET=your_super_secret_jwt_key_change_this
JWT_EXPIRE=7d

# Cloudinary
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret

# Frontend
FRONTEND_URL=http://localhost:5173

# Red Flag Detection
MAX_GPS_DISTANCE_KM=5
RED_FLAG_SCAN_CRON=0 */6 * * *

# Email (optional)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your_email@gmail.com
SMTP_PASS=your_app_password

# Rate Limiting
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100

Generate the complete folder structure and package.json file.
```

---

## 🗄️ Database Configuration Prompt

```
Create MongoDB connection and configuration files:

FILE 1: src/config/database.js

```javascript
const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    console.log(`✅ MongoDB Connected: ${conn.connection.host}`);
    
    // Handle connection events
    mongoose.connection.on('error', (err) => {
      console.error(`❌ MongoDB connection error: ${err}`);
    });

    mongoose.connection.on('disconnected', () => {
      console.warn('⚠️  MongoDB disconnected');
    });

    // Graceful shutdown
    process.on('SIGINT', async () => {
      await mongoose.connection.close();
      console.log('MongoDB connection closed due to app termination');
      process.exit(0);
    });

  } catch (error) {
    console.error(`❌ Error connecting to MongoDB: ${error.message}`);
    process.exit(1);
  }
};

module.exports = connectDB;
```

---

FILE 2: src/config/cloudinary.js

```javascript
const cloudinary = require('cloudinary').v2;

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

// Helper function to upload image
const uploadToCloudinary = async (filePath, folder = 'petms') => {
  try {
    const result = await cloudinary.uploader.upload(filePath, {
      folder,
      resource_type: 'auto',
      transformation: [
        { width: 1200, height: 800, crop: 'limit' },
        { quality: 'auto:good' },
      ],
    });

    return {
      url: result.secure_url,
      publicId: result.public_id,
      format: result.format,
    };
  } catch (error) {
    console.error('Cloudinary upload error:', error);
    throw new Error('Failed to upload image');
  }
};

// Helper function to delete image
const deleteFromCloudinary = async (publicId) => {
  try {
    await cloudinary.uploader.destroy(publicId);
  } catch (error) {
    console.error('Cloudinary delete error:', error);
  }
};

module.exports = {
  cloudinary,
  uploadToCloudinary,
  deleteFromCloudinary,
};
```

---

FILE 3: src/config/constants.js

```javascript
module.exports = {
  // User Roles
  ROLES: {
    ADMIN: 'admin',
    CONTRACTOR: 'contractor',
    CITIZEN: 'citizen',
  },

  // Project Status
  PROJECT_STATUS: {
    ON_TIME: 'On Time',
    DELAYED: 'Delayed',
    CRITICAL: 'Critical',
    COMPLETED: 'Completed',
  },

  // Complaint Status
  COMPLAINT_STATUS: {
    PENDING: 'Pending',
    UNDER_REVIEW: 'Under Review',
    RESOLVED: 'Resolved',
    CLOSED: 'Closed',
  },

  // Departments
  DEPARTMENTS: [
    'Roads & Infrastructure',
    'Healthcare',
    'Education',
    'Smart City',
    'Rural Development',
    'Water Supply',
    'Sanitation',
    'Energy',
    'Others',
  ],

  // Red Flag Thresholds
  RED_FLAG_THRESHOLDS: {
    BUDGET_OVERRUN_PERCENT: 90, // 90% spent
    COMPLETION_LAG_PERCENT: 50, // but <50% complete
    DELAY_DAYS: 30,
    BUDGET_SPIKE_PERCENT: 20,
    GPS_MAX_DISTANCE_KM: 5,
    CRITICAL_UPVOTES: 100,
  },

  // File Upload Limits
  FILE_LIMITS: {
    MAX_FILE_SIZE: 5 * 1024 * 1024, // 5MB
    ALLOWED_TYPES: ['image/jpeg', 'image/jpg', 'image/png'],
    MAX_FILES_PER_UPLOAD: 5,
  },
};
```

Generate all configuration files with proper error handling.
```

---

## 📊 Database Models Prompt

```
Create Mongoose schemas for PETMS:

FILE 1: src/models/User.js

```javascript
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Name is required'],
      trim: true,
      maxlength: [100, 'Name cannot exceed 100 characters'],
    },
    email: {
      type: String,
      required: [true, 'Email is required'],
      unique: true,
      lowercase: true,
      trim: true,
      match: [
        /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
        'Please provide a valid email',
      ],
    },
    password: {
      type: String,
      required: [true, 'Password is required'],
      minlength: [6, 'Password must be at least 6 characters'],
      select: false, // Don't return password in queries by default
    },
    role: {
      type: String,
      enum: ['admin', 'contractor', 'citizen'],
      required: [true, 'Role is required'],
    },
    phone: {
      type: String,
      match: [/^[6-9]\d{9}$/, 'Please provide a valid Indian phone number'],
    },
    avatar: {
      type: String,
      default: 'https://via.placeholder.com/150',
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    lastLogin: {
      type: Date,
    },
  },
  {
    timestamps: true,
  }
);

// Hash password before saving
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) {
    return next();
  }
  
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

// Compare password method
userSchema.methods.comparePassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

// Generate JWT token
userSchema.methods.generateToken = function () {
  return jwt.sign(
    { id: this._id, role: this.role },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRE }
  );
};

module.exports = mongoose.model('User', userSchema);
```

---

FILE 2: src/models/Project.js

```javascript
const mongoose = require('mongoose');

const projectSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Project title is required'],
      trim: true,
      maxlength: [200, 'Title cannot exceed 200 characters'],
    },
    description: {
      type: String,
      required: [true, 'Description is required'],
      maxlength: [2000, 'Description cannot exceed 2000 characters'],
    },
    department: {
      type: String,
      required: [true, 'Department is required'],
      enum: [
        'Roads & Infrastructure',
        'Healthcare',
        'Education',
        'Smart City',
        'Rural Development',
        'Water Supply',
        'Sanitation',
        'Energy',
        'Others',
      ],
    },
    location: {
      address: {
        type: String,
        required: true,
      },
      city: {
        type: String,
        required: true,
      },
      state: {
        type: String,
        required: true,
      },
      pincode: {
        type: String,
        match: [/^[1-9][0-9]{5}$/, 'Invalid pincode'],
      },
      coordinates: {
        latitude: {
          type: Number,
          required: true,
          min: -90,
          max: 90,
        },
        longitude: {
          type: Number,
          required: true,
          min: -180,
          max: 180,
        },
      },
    },
    totalBudget: {
      type: Number,
      required: [true, 'Total budget is required'],
      min: [0, 'Budget cannot be negative'],
    },
    amountSpent: {
      type: Number,
      default: 0,
      min: [0, 'Amount spent cannot be negative'],
    },
    completionPercentage: {
      type: Number,
      default: 0,
      min: [0, 'Completion cannot be negative'],
      max: [100, 'Completion cannot exceed 100%'],
    },
    startDate: {
      type: Date,
      required: [true, 'Start date is required'],
    },
    expectedEndDate: {
      type: Date,
      required: [true, 'Expected end date is required'],
    },
    actualEndDate: {
      type: Date,
    },
    status: {
      type: String,
      enum: ['On Time', 'Delayed', 'Critical', 'Completed'],
      default: 'On Time',
    },
    riskFlag: {
      type: Boolean,
      default: false,
    },
    riskFactors: [
      {
        type: String,
        enum: [
          'BUDGET_OVERRUN',
          'TIMELINE_DELAY',
          'BUDGET_SPIKE',
          'GPS_FRAUD',
          'PUBLIC_CONCERN',
        ],
      },
    ],
    contractor: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    images: [
      {
        url: String,
        publicId: String,
        uploadedAt: {
          type: Date,
          default: Date.now,
        },
      },
    ],
    budgetHistory: [
      {
        amount: Number,
        reason: String,
        updatedAt: {
          type: Date,
          default: Date.now,
        },
      },
    ],
    isActive: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// Virtual for delay calculation
projectSchema.virtual('delayDays').get(function () {
  if (this.status === 'Completed') return 0;
  
  const today = new Date();
  const expectedEnd = new Date(this.expectedEndDate);
  
  if (today > expectedEnd) {
    const diffTime = Math.abs(today - expectedEnd);
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }
  
  return 0;
});

// Virtual for spending percentage
projectSchema.virtual('spendingPercentage').get(function () {
  return ((this.amountSpent / this.totalBudget) * 100).toFixed(2);
});

// Index for geospatial queries
projectSchema.index({ 'location.coordinates': '2dsphere' });

module.exports = mongoose.model('Project', projectSchema);
```

---

FILE 3: src/models/Complaint.js

```javascript
const mongoose = require('mongoose');

const complaintSchema = new mongoose.Schema(
  {
    project: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Project',
      required: [true, 'Project reference is required'],
    },
    citizen: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Citizen reference is required'],
    },
    issueType: {
      type: String,
      required: [true, 'Issue type is required'],
      enum: [
        'Poor Quality',
        'Work Stopped',
        'Budget Misuse',
        'Timeline Delay',
        'Other',
      ],
    },
    description: {
      type: String,
      required: [true, 'Description is required'],
      minlength: [50, 'Description must be at least 50 characters'],
      maxlength: [1000, 'Description cannot exceed 1000 characters'],
    },
    images: [
      {
        url: String,
        publicId: String,
        uploadedAt: {
          type: Date,
          default: Date.now,
        },
      },
    ],
    location: {
      latitude: {
        type: Number,
        required: true,
      },
      longitude: {
        type: Number,
        required: true,
      },
    },
    status: {
      type: String,
      enum: ['Pending', 'Under Review', 'Resolved', 'Closed'],
      default: 'Pending',
    },
    upvotes: {
      type: Number,
      default: 0,
    },
    upvotedBy: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
      },
    ],
    adminResponse: {
      message: String,
      respondedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
      },
      respondedAt: Date,
    },
    trackingId: {
      type: String,
      unique: true,
    },
    isCritical: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);

// Generate tracking ID before saving
complaintSchema.pre('save', async function (next) {
  if (!this.trackingId) {
    const year = new Date().getFullYear();
    const count = await mongoose.model('Complaint').countDocuments();
    this.trackingId = `CMP${year}${String(count + 1).padStart(6, '0')}`;
  }
  
  // Mark as critical if upvotes exceed threshold
  if (this.upvotes >= 100) {
    this.isCritical = true;
  }
  
  next();
});

module.exports = mongoose.model('Complaint', complaintSchema);
```

---

FILE 4: src/models/Update.js

```javascript
const mongoose = require('mongoose');

const updateSchema = new mongoose.Schema(
  {
    project: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Project',
      required: true,
    },
    contractor: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    previousCompletion: {
      type: Number,
      required: true,
    },
    newCompletion: {
      type: Number,
      required: true,
    },
    previousAmountSpent: {
      type: Number,
      required: true,
    },
    newAmountSpent: {
      type: Number,
      required: true,
    },
    photos: [
      {
        url: String,
        publicId: String,
        gpsData: {
          latitude: Number,
          longitude: Number,
        },
        distanceFromSite: Number,
        isValid: Boolean,
        uploadedAt: {
          type: Date,
          default: Date.now,
        },
      },
    ],
    notes: {
      type: String,
      maxlength: [500, 'Notes cannot exceed 500 characters'],
    },
    isApproved: {
      type: Boolean,
      default: false,
    },
    approvedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    approvedAt: Date,
    rejectionReason: String,
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model('Update', updateSchema);
```

Generate all models with proper validations and virtuals.
```

---

## 🔐 Authentication System Prompt

```
Create authentication controllers and routes:

FILE 1: src/controllers/auth.controller.js

```javascript
const User = require('../models/User');
const { successResponse, errorResponse } = require('../utils/response.utils');

// @desc    Register a new user
// @route   POST /api/auth/register
// @access  Public
exports.register = async (req, res) => {
  try {
    const { name, email, password, role, phone } = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return errorResponse(res, 'User already exists with this email', 400);
    }

    // Create user
    const user = await User.create({
      name,
      email,
      password,
      role,
      phone,
    });

    // Generate token
    const token = user.generateToken();

    // Remove password from response
    user.password = undefined;

    return successResponse(res, 'User registered successfully', {
      user,
      token,
    }, 201);
  } catch (error) {
    console.error('Registration error:', error);
    return errorResponse(res, 'Registration failed', 500);
  }
};

// @desc    Login user
// @route   POST /api/auth/login
// @access  Public
exports.login = async (req, res) => {
  try {
    const { email, password, role } = req.body;

    // Validate input
    if (!email || !password || !role) {
      return errorResponse(res, 'Please provide email, password, and role', 400);
    }

    // Find user and include password
    const user = await User.findOne({ email, role }).select('+password');
    
    if (!user) {
      return errorResponse(res, 'Invalid credentials', 401);
    }

    // Check if user is active
    if (!user.isActive) {
      return errorResponse(res, 'Account is deactivated', 403);
    }

    // Verify password
    const isPasswordValid = await user.comparePassword(password);
    
    if (!isPasswordValid) {
      return errorResponse(res, 'Invalid credentials', 401);
    }

    // Update last login
    user.lastLogin = new Date();
    await user.save();

    // Generate token
    const token = user.generateToken();

    // Remove password from response
    user.password = undefined;

    return successResponse(res, 'Login successful', {
      user,
      token,
    });
  } catch (error) {
    console.error('Login error:', error);
    return errorResponse(res, 'Login failed', 500);
  }
};

// @desc    Get current user
// @route   GET /api/auth/me
// @access  Private
exports.getMe = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    
    return successResponse(res, 'User retrieved successfully', { user });
  } catch (error) {
    console.error('Get user error:', error);
    return errorResponse(res, 'Failed to get user', 500);
  }
};

// @desc    Logout user
// @route   POST /api/auth/logout
// @access  Private
exports.logout = async (req, res) => {
  try {
    // In a real app with refresh tokens, invalidate the token here
    return successResponse(res, 'Logged out successfully');
  } catch (error) {
    return errorResponse(res, 'Logout failed', 500);
  }
};
```

---

FILE 2: src/middleware/auth.middleware.js

```javascript
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { errorResponse } = require('../utils/response.utils');

exports.protect = async (req, res, next) => {
  try {
    let token;

    // Get token from header
    if (
      req.headers.authorization &&
      req.headers.authorization.startsWith('Bearer')
    ) {
      token = req.headers.authorization.split(' ')[1];
    }

    // Check if token exists
    if (!token) {
      return errorResponse(res, 'Not authorized to access this route', 401);
    }

    try {
      // Verify token
      const decoded = jwt.verify(token, process.env.JWT_SECRET);

      // Find user
      req.user = await User.findById(decoded.id);

      if (!req.user) {
        return errorResponse(res, 'User not found', 404);
      }

      if (!req.user.isActive) {
        return errorResponse(res, 'Account is deactivated', 403);
      }

      next();
    } catch (error) {
      return errorResponse(res, 'Invalid token', 401);
    }
  } catch (error) {
    return errorResponse(res, 'Authentication failed', 500);
  }
};

// Authorize specific roles
exports.authorize = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return errorResponse(
        res,
        `User role '${req.user.role}' is not authorized to access this route`,
        403
      );
    }
    next();
  };
};
```

---

FILE 3: src/routes/auth.routes.js

```javascript
const express = require('express');
const router = express.Router();
const {
  register,
  login,
  getMe,
  logout,
} = require('../controllers/auth.controller');
const { protect } = require('../middleware/auth.middleware');
const { validateRegister, validateLogin } = require('../validators/auth.validator');

// Public routes
router.post('/register', validateRegister, register);
router.post('/login', validateLogin, login);

// Protected routes
router.get('/me', protect, getMe);
router.post('/logout', protect, logout);

module.exports = router;
```

---

FILE 4: src/validators/auth.validator.js

```javascript
const { body, validationResult } = require('express-validator');
const { errorResponse } = require('../utils/response.utils');

exports.validateRegister = [
  body('name')
    .trim()
    .notEmpty()
    .withMessage('Name is required')
    .isLength({ max: 100 })
    .withMessage('Name cannot exceed 100 characters'),
  
  body('email')
    .trim()
    .notEmpty()
    .withMessage('Email is required')
    .isEmail()
    .withMessage('Please provide a valid email')
    .normalizeEmail(),
  
  body('password')
    .notEmpty()
    .withMessage('Password is required')
    .isLength({ min: 6 })
    .withMessage('Password must be at least 6 characters'),
  
  body('role')
    .notEmpty()
    .withMessage('Role is required')
    .isIn(['admin', 'contractor', 'citizen'])
    .withMessage('Invalid role'),
  
  body('phone')
    .optional()
    .matches(/^[6-9]\d{9}$/)
    .withMessage('Please provide a valid Indian phone number'),
  
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return errorResponse(res, 'Validation failed', 400, errors.array());
    }
    next();
  },
];

exports.validateLogin = [
  body('email')
    .trim()
    .notEmpty()
    .withMessage('Email is required')
    .isEmail()
    .withMessage('Please provide a valid email'),
  
  body('password')
    .notEmpty()
    .withMessage('Password is required'),
  
  body('role')
    .notEmpty()
    .withMessage('Role is required')
    .isIn(['admin', 'contractor', 'citizen'])
    .withMessage('Invalid role'),
  
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return errorResponse(res, 'Validation failed', 400, errors.array());
    }
    next();
  },
];
```

Generate complete authentication system with JWT, password hashing, and validation.
```

---

## 📦 Project Management Prompt

```
Create project CRUD operations with red flag detection:

FILE: src/controllers/project.controller.js

```javascript
const Project = require('../models/Project');
const { successResponse, errorResponse } = require('../utils/response.utils');
const { calculateRiskFlag } = require('../utils/redFlag.utils');

// @desc    Get all projects
// @route   GET /api/projects
// @access  Public
exports.getAllProjects = async (req, res) => {
  try {
    const { 
      department, 
      status, 
      riskFlag, 
      city, 
      search,
      page = 1,
      limit = 10,
    } = req.query;

    // Build query
    const query = { isActive: true };

    if (department) query.department = department;
    if (status) query.status = status;
    if (riskFlag !== undefined) query.riskFlag = riskFlag === 'true';
    if (city) query['location.city'] = new RegExp(city, 'i');
    if (search) {
      query.$or = [
        { title: new RegExp(search, 'i') },
        { description: new RegExp(search, 'i') },
      ];
    }

    // Pagination
    const skip = (page - 1) * limit;

    // Execute query
    const projects = await Project.find(query)
      .populate('contractor', 'name email phone')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Project.countDocuments(query);

    return successResponse(res, 'Projects retrieved successfully', {
      projects,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Get projects error:', error);
    return errorResponse(res, 'Failed to get projects', 500);
  }
};

// @desc    Get single project
// @route   GET /api/projects/:id
// @access  Public
exports.getProject = async (req, res) => {
  try {
    const project = await Project.findById(req.params.id)
      .populate('contractor', 'name email phone');

    if (!project) {
      return errorResponse(res, 'Project not found', 404);
    }

    return successResponse(res, 'Project retrieved successfully', { project });
  } catch (error) {
    console.error('Get project error:', error);
    return errorResponse(res, 'Failed to get project', 500);
  }
};

// @desc    Create project
// @route   POST /api/projects
// @access  Private (Admin only)
exports.createProject = async (req, res) => {
  try {
    const project = await Project.create(req.body);

    return successResponse(res, 'Project created successfully', { project }, 201);
  } catch (error) {
    console.error('Create project error:', error);
    return errorResponse(res, 'Failed to create project', 500);
  }
};

// @desc    Update project
// @route   PUT /api/projects/:id
// @access  Private (Admin only)
exports.updateProject = async (req, res) => {
  try {
    let project = await Project.findById(req.params.id);

    if (!project) {
      return errorResponse(res, 'Project not found', 404);
    }

    // Track budget changes
    if (req.body.totalBudget && req.body.totalBudget !== project.totalBudget) {
      project.budgetHistory.push({
        amount: req.body.totalBudget,
        reason: req.body.budgetChangeReason || 'Budget updated',
      });
    }

    project = await Project.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });

    // Recalculate risk flag
    const riskData = calculateRiskFlag(project);
    project.riskFlag = riskData.isRisky;
    project.riskFactors = riskData.factors;
    await project.save();

    return successResponse(res, 'Project updated successfully', { project });
  } catch (error) {
    console.error('Update project error:', error);
    return errorResponse(res, 'Failed to update project', 500);
  }
};

// @desc    Delete project
// @route   DELETE /api/projects/:id
// @access  Private (Admin only)
exports.deleteProject = async (req, res) => {
  try {
    const project = await Project.findById(req.params.id);

    if (!project) {
      return errorResponse(res, 'Project not found', 404);
    }

    // Soft delete
    project.isActive = false;
    await project.save();

    return successResponse(res, 'Project deleted successfully');
  } catch (error) {
    console.error('Delete project error:', error);
    return errorResponse(res, 'Failed to delete project', 500);
  }
};

// @desc    Get projects by proximity
// @route   GET /api/projects/nearby
// @access  Public
exports.getNearbyProjects = async (req, res) => {
  try {
    const { latitude, longitude, radius = 50 } = req.query; // radius in km

    if (!latitude || !longitude) {
      return errorResponse(res, 'Latitude and longitude are required', 400);
    }

    const projects = await Project.find({
      'location.coordinates': {
        $near: {
          $geometry: {
            type: 'Point',
            coordinates: [parseFloat(longitude), parseFloat(latitude)],
          },
          $maxDistance: radius * 1000, // Convert km to meters
        },
      },
      isActive: true,
    }).populate('contractor', 'name email');

    return successResponse(res, 'Nearby projects retrieved successfully', {
      projects,
      count: projects.length,
    });
  } catch (error) {
    console.error('Get nearby projects error:', error);
    return errorResponse(res, 'Failed to get nearby projects', 500);
  }
};
```

Generate complete project controller with all CRUD operations and filtering.
```

---

## 🚨 Red Flag Detection System Prompt

```
Create the intelligent red flag detection system:

FILE: src/utils/redFlag.utils.js

```javascript
const { RED_FLAG_THRESHOLDS } = require('../config/constants');

/**
 * Calculate risk flag based on multiple factors
 * @param {Object} project - Project document
 * @returns {Object} { isRisky: boolean, riskLevel: number, factors: array }
 */
exports.calculateRiskFlag = (project) => {
  const riskFactors = [];
  
  // Factor 1: Budget Overrun
  // If spent >90% but completion <50%
  const spendingPercent = (project.amountSpent / project.totalBudget) * 100;
  if (
    spendingPercent > RED_FLAG_THRESHOLDS.BUDGET_OVERRUN_PERCENT &&
    project.completionPercentage < RED_FLAG_THRESHOLDS.COMPLETION_LAG_PERCENT
  ) {
    riskFactors.push('BUDGET_OVERRUN');
  }
  
  // Factor 2: Timeline Delay
  // If delayed by more than 30 days
  const delayDays = calculateDelayDays(project.expectedEndDate);
  if (delayDays > RED_FLAG_THRESHOLDS.DELAY_DAYS) {
    riskFactors.push('TIMELINE_DELAY');
  }
  
  // Factor 3: Sudden Budget Spike
  // If budget increased by >20% from original
  if (project.budgetHistory && project.budgetHistory.length > 0) {
    const originalBudget = project.budgetHistory[0].amount;
    const increasePercent = ((project.totalBudget - originalBudget) / originalBudget) * 100;
    
    if (increasePercent > RED_FLAG_THRESHOLDS.BUDGET_SPIKE_PERCENT) {
      riskFactors.push('BUDGET_SPIKE');
    }
  }
  
  // Factor 4: GPS Verification Failed
  // Check if any recent update had GPS mismatch
  // This will be set by the update controller
  
  // Factor 5: High Complaint Volume
  // This will be checked separately in complaint controller
  
  return {
    isRisky: riskFactors.length > 0,
    riskLevel: riskFactors.length, // 0-5 scale
    factors: riskFactors,
  };
};

/**
 * Calculate days of delay
 * @param {Date} expectedEndDate
 * @returns {number} Days delayed (0 if not delayed)
 */
const calculateDelayDays = (expectedEndDate) => {
  const today = new Date();
  const expectedEnd = new Date(expectedEndDate);
  
  if (today > expectedEnd) {
    const diffTime = Math.abs(today - expectedEnd);
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }
  
  return 0;
};

/**
 * Generate risk alert message
 * @param {Array} factors - Array of risk factor codes
 * @returns {string} Human-readable alert message
 */
exports.generateRiskMessage = (factors) => {
  const messages = {
    BUDGET_OVERRUN: 'Spent >90% of budget but only <50% complete',
    TIMELINE_DELAY: 'Project delayed by more than 30 days',
    BUDGET_SPIKE: 'Budget increased by more than 20%',
    GPS_FRAUD: 'GPS verification failed on recent update',
    PUBLIC_CONCERN: 'High number of citizen complaints',
  };
  
  return factors.map(factor => messages[factor]).join('. ');
};

/**
 * Determine alert severity
 * @param {number} riskLevel - Number of risk factors (0-5)
 * @returns {string} 'low' | 'medium' | 'high' | 'critical'
 */
exports.getRiskSeverity = (riskLevel) => {
  if (riskLevel === 0) return 'low';
  if (riskLevel <= 2) return 'medium';
  if (riskLevel <= 3) return 'high';
  return 'critical';
};
```

---

FILE: src/jobs/redFlag.job.js

```javascript
const cron = require('node-cron');
const Project = require('../models/Project');
const { calculateRiskFlag } = require('../utils/redFlag.utils');
const { sendAlertEmail } = require('../utils/email.utils');

/**
 * Automated Red Flag Detection Job
 * Runs every 6 hours to scan all active projects
 */
const redFlagScanJob = cron.schedule(
  process.env.RED_FLAG_SCAN_CRON || '0 */6 * * *',
  async () => {
    console.log('🚨 Running automated red flag detection...');
    
    try {
      const projects = await Project.find({ 
        isActive: true, 
        status: { $ne: 'Completed' } 
      }).populate('contractor', 'name email');

      let flaggedCount = 0;
      let newFlagsCount = 0;

      for (const project of projects) {
        const previousFlag = project.riskFlag;
        
        // Calculate risk
        const riskData = calculateRiskFlag(project);
        
        // Update project
        project.riskFlag = riskData.isRisky;
        project.riskFactors = riskData.factors;
        
        // Update status
        if (riskData.riskLevel >= 3) {
          project.status = 'Critical';
        } else if (riskData.riskLevel > 0) {
          project.status = 'Delayed';
        }
        
        await project.save();
        
        if (riskData.isRisky) {
          flaggedCount++;
          
          // Send alert if newly flagged
          if (!previousFlag && riskData.isRisky) {
            newFlagsCount++;
            
            // Send email to admin
            await sendAlertEmail({
              to: process.env.ADMIN_EMAIL,
              subject: `⚠️ Red Flag Alert: ${project.title}`,
              project,
              riskFactors: riskData.factors,
            });
          }
        }
      }

      console.log(`✅ Red flag scan complete: ${flaggedCount} flagged projects (${newFlagsCount} new)`);
    } catch (error) {
      console.error('❌ Red flag scan error:', error);
    }
  },
  {
    scheduled: false, // Don't start automatically
  }
);

// Start the job
exports.startRedFlagJob = () => {
  redFlagScanJob.start();
  console.log('✅ Red flag detection job started');
};

// Stop the job
exports.stopRedFlagJob = () => {
  redFlagScanJob.stop();
  console.log('⛔ Red flag detection job stopped');
};
```

Generate complete red flag detection system with automated scanning.
```

---

## 📸 GPS Verification System Prompt

```
Create GPS extraction and validation for contractor uploads:

FILE: src/utils/gps.utils.js

```javascript
const exifParser = require('exif-parser');
const fs = require('fs');
const { RED_FLAG_THRESHOLDS } = require('../config/constants');

/**
 * Extract GPS coordinates from image EXIF data
 * @param {string} filePath - Path to image file
 * @returns {Promise<Object>} { latitude, longitude, timestamp }
 */
exports.extractGPSFromImage = async (filePath) => {
  try {
    const buffer = fs.readFileSync(filePath);
    const parser = exifParser.create(buffer);
    const result = parser.parse();
    
    if (!result.tags.GPSLatitude || !result.tags.GPSLongitude) {
      throw new Error('No GPS data found in image');
    }
    
    return {
      latitude: result.tags.GPSLatitude,
      longitude: result.tags.GPSLongitude,
      timestamp: result.tags.DateTimeOriginal || null,
      hasGPS: true,
    };
  } catch (error) {
    console.error('GPS extraction error:', error);
    return {
      hasGPS: false,
      error: error.message,
    };
  }
};

/**
 * Calculate distance between two GPS coordinates using Haversine formula
 * @param {Object} coord1 - { latitude, longitude }
 * @param {Object} coord2 - { latitude, longitude }
 * @returns {number} Distance in kilometers
 */
exports.calculateDistance = (coord1, coord2) => {
  const toRad = (value) => (value * Math.PI) / 180;
  
  const lat1 = coord1.latitude;
  const lon1 = coord1.longitude;
  const lat2 = coord2.latitude;
  const lon2 = coord2.longitude;
  
  const R = 6371; // Earth's radius in km
  
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) *
      Math.cos(toRad(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;
  
  return distance; // in kilometers
};

/**
 * Validate GPS location against project site
 * @param {Object} photoGPS - GPS from uploaded photo
 * @param {Object} projectGPS - Project site GPS coordinates
 * @param {number} maxDistanceKM - Maximum allowed distance
 * @returns {Object} { isValid, distance, message }
 */
exports.validateGPSLocation = (photoGPS, projectGPS, maxDistanceKM = null) => {
  const maxDistance = maxDistanceKM || RED_FLAG_THRESHOLDS.GPS_MAX_DISTANCE_KM;
  
  const distance = this.calculateDistance(photoGPS, projectGPS);
  const isValid = distance <= maxDistance;
  
  return {
    isValid,
    distance: parseFloat(distance.toFixed(2)),
    message: isValid
      ? `✓ Valid (${distance.toFixed(2)} km from site)`
      : `✗ Too far (${distance.toFixed(2)} km from site - max ${maxDistance} km allowed)`,
  };
};

/**
 * Process multiple images and validate GPS
 * @param {Array} files - Array of file objects
 * @param {Object} projectLocation - Project GPS coordinates
 * @returns {Promise<Array>} Array of processed file data
 */
exports.processAndValidateImages = async (files, projectLocation) => {
  const processedFiles = [];
  
  for (const file of files) {
    try {
      // Extract GPS
      const gpsData = await this.extractGPSFromImage(file.path);
      
      let validation = null;
      if (gpsData.hasGPS) {
        // Validate location
        validation = this.validateGPSLocation(
          { latitude: gpsData.latitude, longitude: gpsData.longitude },
          projectLocation
        );
      }
      
      processedFiles.push({
        originalName: file.originalname,
        path: file.path,
        gpsData: gpsData.hasGPS ? {
          latitude: gpsData.latitude,
          longitude: gpsData.longitude,
          timestamp: gpsData.timestamp,
        } : null,
        validation,
        hasGPS: gpsData.hasGPS,
      });
    } catch (error) {
      console.error(`Error processing file ${file.originalname}:`, error);
      processedFiles.push({
        originalName: file.originalname,
        path: file.path,
        error: error.message,
        hasGPS: false,
      });
    }
  }
  
  return processedFiles;
};
```

---

FILE: src/middleware/upload.middleware.js

```javascript
const multer = require('multer');
const path = require('path');
const { FILE_LIMITS } = require('../config/constants');
const { errorResponse } = require('../utils/response.utils');

// Configure multer storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  },
});

// File filter
const fileFilter = (req, file, cb) => {
  if (FILE_LIMITS.ALLOWED_TYPES.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('Invalid file type. Only JPEG, JPG, and PNG are allowed.'), false);
  }
};

// Create multer upload instance
const upload = multer({
  storage,
  limits: {
    fileSize: FILE_LIMITS.MAX_FILE_SIZE,
  },
  fileFilter,
});

// Error handling middleware
exports.handleUploadError = (err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    if (err.code === 'LIMIT_FILE_SIZE') {
      return errorResponse(res, 'File too large. Maximum size is 5MB.', 400);
    }
    if (err.code === 'LIMIT_FILE_COUNT') {
      return errorResponse(res, `Maximum ${FILE_LIMITS.MAX_FILES_PER_UPLOAD} files allowed.`, 400);
    }
  } else if (err) {
    return errorResponse(res, err.message, 400);
  }
  next();
};

// Export upload instances
exports.uploadSingle = upload.single('image');
exports.uploadMultiple = upload.array('images', FILE_LIMITS.MAX_FILES_PER_UPLOAD);
```

Generate complete GPS validation system with image processing.
```

---

## 📝 Complaint System Prompt

```
Create complaint management with upvote system:

FILE: src/controllers/complaint.controller.js

```javascript
const Complaint = require('../models/Complaint');
const Project = require('../models/Project');
const { successResponse, errorResponse } = require('../utils/response.utils');
const { uploadToCloudinary } = require('../config/cloudinary');
const fs = require('fs');

// @desc    Submit complaint
// @route   POST /api/complaints
// @access  Private (Citizen only)
exports.submitComplaint = async (req, res) => {
  try {
    const { projectId, issueType, description, latitude, longitude } = req.body;

    // Verify project exists
    const project = await Project.findById(projectId);
    if (!project) {
      return errorResponse(res, 'Project not found', 404);
    }

    // Upload images to Cloudinary
    const images = [];
    if (req.files && req.files.length > 0) {
      for (const file of req.files) {
        const result = await uploadToCloudinary(file.path, 'petms/complaints');
        images.push({
          url: result.url,
          publicId: result.publicId,
        });
        
        // Delete local file
        fs.unlinkSync(file.path);
      }
    }

    // Create complaint
    const complaint = await Complaint.create({
      project: projectId,
      citizen: req.user.id,
      issueType,
      description,
      images,
      location: {
        latitude: parseFloat(latitude),
        longitude: parseFloat(longitude),
      },
    });

    await complaint.populate('project', 'title location');
    await complaint.populate('citizen', 'name email');

    return successResponse(res, 'Complaint submitted successfully', {
      complaint,
      trackingId: complaint.trackingId,
    }, 201);
  } catch (error) {
    console.error('Submit complaint error:', error);
    return errorResponse(res, 'Failed to submit complaint', 500);
  }
};

// @desc    Get all complaints
// @route   GET /api/complaints
// @access  Private
exports.getAllComplaints = async (req, res) => {
  try {
    const { 
      projectId, 
      status, 
      isCritical,
      page = 1,
      limit = 10,
    } = req.query;

    const query = {};

    // Filters
    if (projectId) query.project = projectId;
    if (status) query.status = status;
    if (isCritical !== undefined) query.isCritical = isCritical === 'true';

    // Role-based filtering
    if (req.user.role === 'citizen') {
      query.citizen = req.user.id;
    }

    const skip = (page - 1) * limit;

    const complaints = await Complaint.find(query)
      .populate('project', 'title location department')
      .populate('citizen', 'name email')
      .populate('adminResponse.respondedBy', 'name')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Complaint.countDocuments(query);

    return successResponse(res, 'Complaints retrieved successfully', {
      complaints,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Get complaints error:', error);
    return errorResponse(res, 'Failed to get complaints', 500);
  }
};

// @desc    Get single complaint
// @route   GET /api/complaints/:id
// @access  Private
exports.getComplaint = async (req, res) => {
  try {
    const complaint = await Complaint.findById(req.params.id)
      .populate('project', 'title location department')
      .populate('citizen', 'name email phone')
      .populate('adminResponse.respondedBy', 'name email');

    if (!complaint) {
      return errorResponse(res, 'Complaint not found', 404);
    }

    // Check authorization
    if (
      req.user.role === 'citizen' &&
      complaint.citizen._id.toString() !== req.user.id
    ) {
      return errorResponse(res, 'Not authorized to view this complaint', 403);
    }

    return successResponse(res, 'Complaint retrieved successfully', { complaint });
  } catch (error) {
    console.error('Get complaint error:', error);
    return errorResponse(res, 'Failed to get complaint', 500);
  }
};

// @desc    Upvote complaint
// @route   POST /api/complaints/:id/upvote
// @access  Private (Citizen only)
exports.upvoteComplaint = async (req, res) => {
  try {
    const complaint = await Complaint.findById(req.params.id);

    if (!complaint) {
      return errorResponse(res, 'Complaint not found', 404);
    }

    // Check if already upvoted
    const alreadyUpvoted = complaint.upvotedBy.includes(req.user.id);

    if (alreadyUpvoted) {
      // Remove upvote
      complaint.upvotedBy = complaint.upvotedBy.filter(
        (id) => id.toString() !== req.user.id
      );
      complaint.upvotes -= 1;
    } else {
      // Add upvote
      complaint.upvotedBy.push(req.user.id);
      complaint.upvotes += 1;
    }

    await complaint.save();

    return successResponse(res, alreadyUpvoted ? 'Upvote removed' : 'Complaint upvoted', {
      upvotes: complaint.upvotes,
      hasUpvoted: !alreadyUpvoted,
    });
  } catch (error) {
    console.error('Upvote error:', error);
    return errorResponse(res, 'Failed to upvote complaint', 500);
  }
};

// @desc    Respond to complaint (Admin)
// @route   PUT /api/complaints/:id/respond
// @access  Private (Admin only)
exports.respondToComplaint = async (req, res) => {
  try {
    const { message, status } = req.body;

    const complaint = await Complaint.findById(req.params.id);

    if (!complaint) {
      return errorResponse(res, 'Complaint not found', 404);
    }

    complaint.adminResponse = {
      message,
      respondedBy: req.user.id,
      respondedAt: new Date(),
    };

    if (status) {
      complaint.status = status;
    }

    await complaint.save();

    await complaint.populate('adminResponse.respondedBy', 'name email');

    return successResponse(res, 'Response added successfully', { complaint });
  } catch (error) {
    console.error('Respond error:', error);
    return errorResponse(res, 'Failed to respond to complaint', 500);
  }
};
```

Generate complete complaint system with upvoting and admin responses.
```

---

## 📊 Analytics & Stats Prompt

```
Create analytics endpoints for dashboards:

FILE: src/controllers/stats.controller.js

```javascript
const Project = require('../models/Project');
const Complaint = require('../models/Complaint');
const { successResponse, errorResponse } = require('../utils/response.utils');

// @desc    Get overall statistics
// @route   GET /api/stats/overview
// @access  Private (Admin)
exports.getOverviewStats = async (req, res) => {
  try {
    // Total budget allocated
    const totalBudget = await Project.aggregate([
      { $match: { isActive: true } },
      { $group: { _id: null, total: { $sum: '$totalBudget' } } },
    ]);

    // Total amount spent
    const totalSpent = await Project.aggregate([
      { $match: { isActive: true } },
      { $group: { _id: null, total: { $sum: '$amountSpent' } } },
    ]);

    // Project counts by status
    const projectCounts = await Project.aggregate([
      { $match: { isActive: true } },
      { $group: { _id: '$status', count: { $sum: 1 } } },
    ]);

    // Risk flagged projects
    const riskCount = await Project.countDocuments({
      isActive: true,
      riskFlag: true,
    });

    // Pending complaints
    const pendingComplaints = await Complaint.countDocuments({
      status: 'Pending',
    });

    // Critical complaints
    const criticalComplaints = await Complaint.countDocuments({
      isCritical: true,
      status: { $ne: 'Resolved' },
    });

    return successResponse(res, 'Overview stats retrieved successfully', {
      totalBudgetAllocated: totalBudget[0]?.total || 0,
      totalBudgetSpent: totalSpent[0]?.total || 0,
      utilizationPercentage: totalBudget[0]?.total
        ? ((totalSpent[0]?.total / totalBudget[0]?.total) * 100).toFixed(2)
        : 0,
      projectCounts: projectCounts.reduce((acc, item) => {
        acc[item._id] = item.count;
        return acc;
      }, {}),
      activeProjects: projectCounts.reduce((sum, item) => sum + item.count, 0),
      riskFlaggedProjects: riskCount,
      pendingComplaints,
      criticalComplaints,
    });
  } catch (error) {
    console.error('Get overview stats error:', error);
    return errorResponse(res, 'Failed to get stats', 500);
  }
};

// @desc    Get budget allocation by department
// @route   GET /api/stats/department-allocation
// @access  Private (Admin)
exports.getDepartmentAllocation = async (req, res) => {
  try {
    const allocation = await Project.aggregate([
      { $match: { isActive: true } },
      {
        $group: {
          _id: '$department',
          totalBudget: { $sum: '$totalBudget' },
          totalSpent: { $sum: '$amountSpent' },
          projectCount: { $sum: 1 },
        },
      },
      {
        $project: {
          department: '$_id',
          totalBudget: 1,
          totalSpent: 1,
          projectCount: 1,
          utilizationPercentage: {
            $multiply: [
              { $divide: ['$totalSpent', '$totalBudget'] },
              100,
            ],
          },
        },
      },
      { $sort: { totalBudget: -1 } },
    ]);

    return successResponse(res, 'Department allocation retrieved successfully', {
      allocation,
    });
  } catch (error) {
    console.error('Get department allocation error:', error);
    return errorResponse(res, 'Failed to get allocation', 500);
  }
};

// @desc    Get monthly spending trends
// @route   GET /api/stats/monthly-trends
// @access  Private (Admin)
exports.getMonthlyTrends = async (req, res) => {
  try {
    const { months = 6 } = req.query;

    const trends = await Project.aggregate([
      { $match: { isActive: true } },
      {
        $project: {
          month: { $month: '$createdAt' },
          year: { $year: '$createdAt' },
          totalBudget: 1,
          amountSpent: 1,
        },
      },
      {
        $group: {
          _id: { month: '$month', year: '$year' },
          totalAllocated: { $sum: '$totalBudget' },
          totalSpent: { $sum: '$amountSpent' },
        },
      },
      { $sort: { '_id.year': -1, '_id.month': -1 } },
      { $limit: parseInt(months) },
    ]);

    return successResponse(res, 'Monthly trends retrieved successfully', {
      trends,
    });
  } catch (error) {
    console.error('Get monthly trends error:', error);
    return errorResponse(res, 'Failed to get trends', 500);
  }
};

// @desc    Get contractor statistics
// @route   GET /api/stats/contractor
// @access  Private (Contractor)
exports.getContractorStats = async (req, res) => {
  try {
    const projects = await Project.find({
      contractor: req.user.id,
      isActive: true,
    });

    const totalProjects = projects.length;
    const completedProjects = projects.filter(
      (p) => p.status === 'Completed'
    ).length;
    const activeProjects = totalProjects - completedProjects;

    const totalBudget = projects.reduce((sum, p) => sum + p.totalBudget, 0);
    const totalSpent = projects.reduce((sum, p) => sum + p.amountSpent, 0);

    const avgCompletion =
      projects.reduce((sum, p) => sum + p.completionPercentage, 0) /
      totalProjects || 0;

    const delayedProjects = projects.filter(
      (p) => p.status === 'Delayed'
    ).length;

    return successResponse(res, 'Contractor stats retrieved successfully', {
      totalProjects,
      activeProjects,
      completedProjects,
      totalBudgetAssigned: totalBudget,
      totalSpent,
      averageCompletion: avgCompletion.toFixed(2),
      delayedProjects,
    });
  } catch (error) {
    console.error('Get contractor stats error:', error);
    return errorResponse(res, 'Failed to get stats', 500);
  }
};
```

Generate complete analytics system with aggregation queries.
```

---

## 🔧 Utility Functions Prompt

```
Create helper utilities:

FILE: src/utils/response.utils.js

```javascript
/**
 * Send success response
 */
exports.successResponse = (res, message, data = null, statusCode = 200) => {
  const response = {
    success: true,
    message,
  };

  if (data) {
    response.data = data;
  }

  return res.status(statusCode).json(response);
};

/**
 * Send error response
 */
exports.errorResponse = (res, message, statusCode = 500, errors = null) => {
  const response = {
    success: false,
    message,
  };

  if (errors) {
    response.errors = errors;
  }

  return res.status(statusCode).json(response);
};
```

---

FILE: src/utils/email.utils.js

```javascript
const nodemailer = require('nodemailer');

// Create transporter
const transporter = nodemailer.createTransporter({
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT,
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

/**
 * Send email
 */
exports.sendEmail = async ({ to, subject, html }) => {
  try {
    const info = await transporter.sendMail({
      from: `PETMS <${process.env.SMTP_USER}>`,
      to,
      subject,
      html,
    });

    console.log('Email sent:', info.messageId);
    return true;
  } catch (error) {
    console.error('Email error:', error);
    return false;
  }
};

/**
 * Send red flag alert email
 */
exports.sendAlertEmail = async ({ to, subject, project, riskFactors }) => {
  const html = `
    <h2>⚠️ Red Flag Alert</h2>
    <p>Project: <strong>${project.title}</strong></p>
    <p>Location: ${project.location.city}, ${project.location.state}</p>
    <p>Risk Factors:</p>
    <ul>
      ${riskFactors.map((factor) => `<li>${factor}</li>`).join('')}
    </ul>
    <p>Please investigate immediately.</p>
  `;

  return this.sendEmail({ to, subject, html });
};
```

Generate all utility functions with proper error handling.
```

---

## 🚀 Main Server Setup Prompt

```
Create the main Express application and server:

FILE: src/app.js

```javascript
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

// Import routes
const authRoutes = require('./routes/auth.routes');
const projectRoutes = require('./routes/project.routes');
const complaintRoutes = require('./routes/complaint.routes');
const statsRoutes = require('./routes/stats.routes');

// Import middleware
const { errorHandler } = require('./middleware/error.middleware');

const app = express();

// Security middleware
app.use(helmet());

// CORS
app.use(
  cors({
    origin: process.env.FRONTEND_URL || 'http://localhost:5173',
    credentials: true,
  })
);

// Body parser
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Logging
if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
}

// Rate limiting
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000,
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100,
  message: 'Too many requests from this IP, please try again later.',
});

app.use('/api', limiter);

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/projects', projectRoutes);
app.use('/api/complaints', complaintRoutes);
app.use('/api/stats', statsRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: 'Route not found',
  });
});

// Error handler
app.use(errorHandler);

module.exports = app;
```

---

FILE: src/server.js

```javascript
require('dotenv').config();
const app = require('./app');
const connectDB = require('./config/database');
const { startRedFlagJob } = require('./jobs/redFlag.job');

const PORT = process.env.PORT || 5000;

// Connect to database
connectDB();

// Start server
const server = app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT} in ${process.env.NODE_ENV} mode`);
  
  // Start cron jobs
  if (process.env.NODE_ENV === 'production') {
    startRedFlagJob();
  }
});

// Handle unhandled rejections
process.on('unhandledRejection', (err) => {
  console.error('❌ Unhandled Rejection:', err);
  server.close(() => process.exit(1));
});

// Handle SIGTERM
process.on('SIGTERM', () => {
  console.log('👋 SIGTERM received, shutting down gracefully');
  server.close(() => {
    console.log('Process terminated');
  });
});
```

Generate complete server setup with error handling and graceful shutdown.
```

---

## 📋 Seed Data Prompt

```
Create script to populate database with realistic sample data:

FILE: scripts/seed.js

```javascript
require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('../src/models/User');
const Project = require('../src/models/Project');
const Complaint = require('../src/models/Complaint');

const connectDB = async () => {
  await mongoose.connect(process.env.MONGODB_URI);
  console.log('✅ MongoDB connected');
};

const seedData = async () => {
  try {
    await connectDB();

    // Clear existing data
    await User.deleteMany();
    await Project.deleteMany();
    await Complaint.deleteMany();

    console.log('🗑️  Existing data cleared');

    // Create users
    const users = await User.create([
      {
        name: 'Admin User',
        email: 'admin@petms.gov.in',
        password: 'Admin@123',
        role: 'admin',
        phone: '9876543210',
      },
      {
        name: 'Contractor ABC',
        email: 'contractor@example.com',
        password: 'Contractor@123',
        role: 'contractor',
        phone: '9876543211',
      },
      {
        name: 'Citizen User',
        email: 'citizen@example.com',
        password: 'Citizen@123',
        role: 'citizen',
        phone: '9876543212',
      },
    ]);

    console.log('✅ Users created');

    // Create projects
    const projects = await Project.create([
      {
        title: 'Mumbai-Pune Expressway Phase 2',
        description: 'Widening and improvement of existing expressway',
        department: 'Roads & Infrastructure',
        location: {
          address: 'Mumbai-Pune Expressway',
          city: 'Mumbai',
          state: 'Maharashtra',
          pincode: '400001',
          coordinates: { latitude: 19.076, longitude: 72.8777 },
        },
        totalBudget: 5000000000,
        amountSpent: 3500000000,
        completionPercentage: 70,
        startDate: new Date('2024-01-15'),
        expectedEndDate: new Date('2025-12-31'),
        status: 'On Time',
        contractor: users[1]._id,
      },
      {
        title: 'AIIMS Nagpur Construction',
        description: 'New medical facility construction',
        department: 'Healthcare',
        location: {
          address: 'MIHAN, Nagpur',
          city: 'Nagpur',
          state: 'Maharashtra',
          pincode: '440001',
          coordinates: { latitude: 21.1458, longitude: 79.0882 },
        },
        totalBudget: 4500000000,
        amountSpent: 4200000000,
        completionPercentage: 55,
        startDate: new Date('2023-06-01'),
        expectedEndDate: new Date('2025-06-30'),
        status: 'Delayed',
        riskFlag: true,
        riskFactors: ['BUDGET_OVERRUN'],
        contractor: users[1]._id,
      },
      // Add 15-20 more projects...
    ]);

    console.log('✅ Projects created');

    // Create complaints
    await Complaint.create([
      {
        project: projects[1]._id,
        citizen: users[2]._id,
        issueType: 'Poor Quality',
        description: 'The construction quality does not meet standards. Materials used appear to be substandard.',
        location: { latitude: 21.1458, longitude: 79.0882 },
        status: 'Under Review',
        upvotes: 45,
      },
    ]);

    console.log('✅ Complaints created');
    console.log('🎉 Seed data inserted successfully');

    process.exit(0);
  } catch (error) {
    console.error('❌ Seed error:', error);
    process.exit(1);
  }
};

seedData();
```

Generate seed script with 15-20 realistic Indian government projects.
```

---

## ✅ Final Checklist

Before deployment, ensure:

1. ✅ All environment variables configured
2. ✅ MongoDB connection working
3. ✅ Cloudinary credentials set
4. ✅ All routes tested with Postman
5. ✅ GPS extraction working
6. ✅ Red flag detection logic tested
7. ✅ Cron jobs configured
8. ✅ CORS configured for frontend URL
9. ✅ Error handling implemented
10. ✅ Input validation on all routes
11. ✅ File upload size limits set
12. ✅ Rate limiting configured
13. ✅ Security headers (Helmet) active
14. ✅ Logging configured (Morgan)
15. ✅ Seed data script ready

---

## 🚀 Quick Start Commands

```bash
# Install dependencies
npm install

# Setup environment
cp .env.example .env
# Edit .env with your values

# Seed database
node scripts/seed.js

# Development
npm run dev

# Production
npm start
```

---

This comprehensive backend prompting guide will help you build a production-ready PETMS API with all features including authentication, project management, GPS validation, red flag detection, and analytics.
