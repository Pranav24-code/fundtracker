# 🏛️ PETMS - Public Expenditure Transparency & Monitoring System

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)
[![React](https://img.shields.io/badge/React-18.x-61dafb.svg)](https://reactjs.org/)
[![Node.js](https://img.shields.io/badge/Node.js-18.x-339933.svg)](https://nodejs.org/)
[![MongoDB](https://img.shields.io/badge/MongoDB-Atlas-47A248.svg)](https://www.mongodb.com/)

> A comprehensive web-based platform ensuring transparency in public expenditure by enabling citizens to monitor government project allocations, track spending, identify delays, and flag suspicious budget discrepancies in real-time.

---

## 📋 Table of Contents

- [Problem Statement](#-problem-statement)
- [Solution Overview](#-solution-overview)
- [Key Features](#-key-features)
- [Tech Stack](#-tech-stack)
- [Architecture](#-architecture)
- [Project Structure](#-project-structure)
- [Getting Started](#-getting-started)
- [User Roles](#-user-roles)
- [Red Flag Detection System](#-red-flag-detection-system)
- [Deployment](#-deployment)
- [Team & Timeline](#-team--timeline)
- [Screenshots](#-screenshots)
- [Contributing](#-contributing)
- [License](#-license)

---

## 🎯 Problem Statement

In India, large amounts of government funds are allocated annually for:
- 🛣️ Roads and Infrastructure
- 🏫 Schools and Educational Institutions
- 🏥 Hospitals and Healthcare
- 🌆 Smart City Projects
- 🏘️ Rural Development

**Critical Challenges:**
- ❌ Citizens cannot track fund utilization
- ❌ Limited transparency in spending
- ❌ Delays and cost overruns go unnoticed
- ❌ No centralized public dashboard
- ❌ Increased corruption risks due to lack of visibility

---

## 💡 Solution Overview

**PETMS** is a centralized web portal that provides:

✅ **Real-time Monitoring** - Live project tracking and fund allocation visibility  
✅ **Intelligent Risk Detection** - Automated red-flag system for suspicious spending patterns  
✅ **Citizen Empowerment** - Public complaint system with geotagged verification  
✅ **Data Visualization** - Interactive maps, charts, and analytics dashboards  
✅ **Multi-Role Access** - Separate portals for Admins, Contractors, and Citizens  
✅ **Accountability** - GPS-verified progress updates with photo evidence  

---

## 🌟 Key Features

### 🔐 Role-Based Authentication
- **Admin Portal** - Blue theme for government officials
- **Contractor Portal** - Orange theme for project executors
- **Citizen Portal** - Green theme for public watchdogs

### 📊 Advanced Dashboards
- **Admin Dashboard**
  - Real-time budget overview (₹ allocated vs ₹ spent)
  - Project analytics with pie/bar/line charts
  - Risk alert panel with automated flagging
  - Complaint management system
  
- **Contractor Dashboard**
  - Project assignment view
  - Progress update portal with geotagged photo uploads
  - Budget tracking
  - Pending tranche notifications

- **Citizen Dashboard**
  - Interactive map with color-coded project markers
  - Project search and filtering
  - Complaint submission with image upload
  - Complaint tracking system

### 🚨 Red Flag Detection Engine
Automatically identifies suspicious patterns:
- 💰 **Budget Overrun**: >90% spent but <50% complete
- ⏰ **Timeline Delays**: Projects delayed >30 days
- 📈 **Sudden Budget Spikes**: Unexpected increases >20%
- 📍 **GPS Verification Failed**: Location mismatch in uploads

### 🗺️ Interactive Map Visualization
- 🟢 **Green Markers** - Projects on track
- 🟡 **Yellow Markers** - Delayed projects
- 🔴 **Red Markers** - High-risk flagged projects
- Click markers for detailed project popups

### 📸 Geotagged Verification System
- Contractors must upload progress photos with GPS data
- System validates EXIF coordinates against project location
- Rejects uploads >5km away from project site
- Prevents "paper progress" fraud

### 👥 Social Auditing
- Citizens can flag discrepancies with photo evidence
- Upvote system for community validation
- Projects with 100+ upvotes move to critical review
- Real-time citizen feedback timeline

---

## 🛠️ Tech Stack

### Frontend
```
├── React 18.x              # UI Framework
├── Tailwind CSS           # Styling
├── Shadcn/ui              # Component Library
├── Recharts               # Data Visualization
├── Leaflet                # Interactive Maps
├── React Router v6        # Navigation
├── Lucide React           # Icons
└── Zustand                # State Management
```

### Backend
```
├── Node.js 18.x           # Runtime
├── Express.js             # Web Framework
├── MongoDB Atlas          # Database
├── Mongoose               # ODM
├── JWT                    # Authentication
├── Multer                 # File Uploads
├── EXIF Parser            # GPS Extraction
└── Node-cron              # Scheduled Tasks
```

### DevOps & Deployment
```
├── Vercel                 # Frontend Hosting
├── Render                 # Backend Hosting
├── Cloudinary/AWS S3      # Image Storage
└── GitHub Actions         # CI/CD
```

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      User Interface Layer                    │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │ Admin Portal │  │Contractor Hub│  │Citizen Portal│      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                     API Gateway Layer                        │
│                    (Express.js REST API)                     │
└─────────────────────────────────────────────────────────────┘
                            │
        ┌───────────────────┼───────────────────┐
        ▼                   ▼                   ▼
┌──────────────┐  ┌──────────────────┐  ┌──────────────┐
│ Auth Service │  │ Red Flag Engine  │  │ GPS Verifier │
└──────────────┘  └──────────────────┘  └──────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                    Data Persistence Layer                    │
│                      MongoDB Atlas                           │
│  ┌────────┐  ┌─────────┐  ┌────────────┐  ┌──────────┐    │
│  │ Users  │  │Projects │  │ Complaints │  │  Images  │    │
│  └────────┘  └─────────┘  └────────────┘  └──────────┘    │
└─────────────────────────────────────────────────────────────┘
```

---

## 📁 Project Structure

```
petms/
├── frontend/                      # React Application
│   ├── public/
│   ├── src/
│   │   ├── assets/               # Images, icons
│   │   ├── components/           # Reusable components
│   │   │   ├── common/           # Shared UI components
│   │   │   ├── admin/            # Admin-specific components
│   │   │   ├── contractor/       # Contractor-specific components
│   │   │   └── citizen/          # Citizen-specific components
│   │   ├── pages/                # Page components
│   │   │   ├── auth/             # Login pages
│   │   │   ├── admin/            # Admin dashboard
│   │   │   ├── contractor/       # Contractor dashboard
│   │   │   └── citizen/          # Citizen dashboard
│   │   ├── hooks/                # Custom React hooks
│   │   ├── utils/                # Helper functions
│   │   ├── services/             # API integration
│   │   ├── context/              # Context providers
│   │   ├── config/               # Configuration files
│   │   ├── App.jsx               # Root component
│   │   └── main.jsx              # Entry point
│   ├── package.json
│   └── README.md
│
├── backend/                       # Node.js API Server
│   ├── src/
│   │   ├── config/               # Configuration
│   │   │   ├── database.js       # MongoDB connection
│   │   │   ├── cloudinary.js     # Image upload config
│   │   │   └── constants.js      # App constants
│   │   ├── models/               # Mongoose schemas
│   │   │   ├── User.js
│   │   │   ├── Project.js
│   │   │   └── Complaint.js
│   │   ├── routes/               # API routes
│   │   │   ├── auth.routes.js
│   │   │   ├── project.routes.js
│   │   │   └── complaint.routes.js
│   │   ├── controllers/          # Business logic
│   │   │   ├── auth.controller.js
│   │   │   ├── project.controller.js
│   │   │   └── complaint.controller.js
│   │   ├── middleware/           # Custom middleware
│   │   │   ├── auth.middleware.js
│   │   │   ├── upload.middleware.js
│   │   │   └── error.middleware.js
│   │   ├── utils/                # Helper functions
│   │   │   ├── redFlag.utils.js  # Red flag detection
│   │   │   ├── gps.utils.js      # GPS verification
│   │   │   └── validators.js     # Input validation
│   │   ├── jobs/                 # Cron jobs
│   │   │   └── redFlag.job.js    # Automated scanning
│   │   ├── app.js                # Express app setup
│   │   └── server.js             # Server entry point
│   ├── package.json
│   └── README.md
│
├── .gitignore
├── README.md                      # This file
└── LICENSE
```

---

## 🚀 Getting Started

### Prerequisites
- Node.js 18.x or higher
- MongoDB Atlas account (or local MongoDB)
- npm or yarn package manager
- Git

### Installation

1️⃣ **Clone the repository**
```bash
git clone https://github.com/yourusername/petms.git
cd petms
```

2️⃣ **Backend Setup**
```bash
cd backend
npm install

# Create .env file
cp .env.example .env

# Configure environment variables
# MONGODB_URI=your_mongodb_connection_string
# JWT_SECRET=your_jwt_secret
# CLOUDINARY_CLOUD_NAME=your_cloudinary_name
# CLOUDINARY_API_KEY=your_api_key
# CLOUDINARY_API_SECRET=your_api_secret

# Start backend server
npm run dev
```

3️⃣ **Frontend Setup**
```bash
cd ../frontend
npm install

# Create .env file
cp .env.example .env

# Configure environment variables
# VITE_API_URL=http://localhost:5000/api

# Start frontend development server
npm run dev
```

4️⃣ **Access the application**
```
Frontend: http://localhost:5173
Backend API: http://localhost:5000
```

### Default Login Credentials

**Admin:**
- Email: `admin@petms.gov.in`
- Password: `Admin@123`

**Contractor:**
- Email: `contractor@example.com`
- Password: `Contractor@123`

**Citizen:**
- Email: `citizen@example.com`
- Password: `Citizen@123`

---

## 👥 User Roles

### 🏛️ Admin (Government Official)
**Capabilities:**
- ✅ Add and manage projects
- ✅ View system-wide analytics
- ✅ Monitor budget allocation vs spending
- ✅ Review and resolve complaints
- ✅ Access red-flag alert panel
- ✅ Generate PDF reports
- ✅ Approve contractor payments

**Dashboard View:**
- Total budget statistics
- Risk heatmap
- Department-wise spending charts
- Critical project alerts
- Recent complaints feed

---

### 👷 Contractor (Project Executor)
**Capabilities:**
- ✅ View assigned projects
- ✅ Upload geotagged progress photos
- ✅ Update completion percentage
- ✅ Track payment tranches
- ✅ View red flag status
- ✅ Submit progress reports

**Verification Requirements:**
- Must upload photos within 5km of project location
- Photos must include valid GPS EXIF data
- Progress updates trigger automatic red-flag checks

---

### 👤 Citizen (Public Watchdog)
**Capabilities:**
- ✅ Browse all public projects on map
- ✅ Search projects by location/department
- ✅ View detailed project information
- ✅ Raise complaints with photo evidence
- ✅ Upvote existing complaints
- ✅ Track complaint resolution status

**Social Auditing Power:**
- Complaints with 100+ upvotes → Critical review
- Photo evidence required for discrepancy reports
- Real-time project status visibility

---

## 🚨 Red Flag Detection System

### Algorithm Logic

```javascript
function calculateRiskFlag(project) {
  const riskFactors = [];
  
  // Factor 1: Budget Overrun
  if (project.amountSpent / project.totalBudget > 0.9 && 
      project.completionPercentage < 50) {
    riskFactors.push('BUDGET_OVERRUN');
  }
  
  // Factor 2: Timeline Delay
  const delayDays = calculateDelay(project.expectedEndDate);
  if (delayDays > 30) {
    riskFactors.push('TIMELINE_DELAY');
  }
  
  // Factor 3: Sudden Budget Increase
  if (project.budgetIncreasePercentage > 20) {
    riskFactors.push('BUDGET_SPIKE');
  }
  
  // Factor 4: GPS Verification Failed
  if (project.lastUpdateGPSMismatch) {
    riskFactors.push('GPS_FRAUD');
  }
  
  // Factor 5: High Complaint Volume
  if (project.complaintsCount > 50) {
    riskFactors.push('PUBLIC_CONCERN');
  }
  
  return {
    isRisky: riskFactors.length > 0,
    riskLevel: riskFactors.length,
    factors: riskFactors
  };
}
```

### Risk Levels
- 🟢 **Low Risk (0 factors)**: Green marker, normal status
- 🟡 **Medium Risk (1-2 factors)**: Yellow marker, monitoring required
- 🔴 **High Risk (3+ factors)**: Red marker, immediate investigation

### Automated Actions
1. Email alerts to department heads
2. Payment tranche hold for high-risk projects
3. Automatic escalation to senior officials
4. Public visibility on citizen dashboard

---

## 🌐 Deployment

### Frontend (Vercel)
```bash
cd frontend
npm run build
vercel --prod
```

### Backend (Render)
```bash
cd backend
# Push to GitHub
# Connect repository to Render
# Configure environment variables in Render dashboard
# Deploy
```

### Environment Variables Checklist

**Backend (.env):**
```env
NODE_ENV=production
PORT=5000
MONGODB_URI=mongodb+srv://...
JWT_SECRET=your_strong_secret_key
JWT_EXPIRE=7d
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
FRONTEND_URL=https://your-frontend-domain.vercel.app
MAX_GPS_DISTANCE_KM=5
```

**Frontend (.env):**
```env
VITE_API_URL=https://your-backend-domain.render.com/api
VITE_MAPBOX_TOKEN=your_mapbox_token (optional)
```

---

## ⏱️ Team & Timeline

### 12-Hour Hackathon Execution Plan

| Time | Team Member | Task |
|------|-------------|------|
| **Hour 0-1** | All | Setup repo, MongoDB, project structure |
| **Hour 1-6** | Person 1 (Frontend) | Login pages, Dashboard UI, Charts |
| **Hour 6-10** | Person 1 (Frontend) | Map view, Final styling |
| **Hour 1-6** | Person 2 (Backend) | Auth routes, Project CRUD APIs |
| **Hour 6-9** | Person 2 (Backend) | Red flag logic, Complaint APIs |
| **Hour 4-10** | Person 3 (Integration) | Frontend-Backend connection, Testing |
| **Hour 6-12** | Person 4 (Presentation) | Dummy data, UI polish, PPT, Deployment |

### Deliverables
- ✅ Fully functional web application
- ✅ Deployed live demo
- ✅ Presentation deck (PPT)
- ✅ GitHub repository with documentation
- ✅ 4-minute demo video

---

## 🎤 Presentation Strategy

### Opening (30 seconds)
> "India allocates lakhs of crores annually to public projects, but citizens lack visibility into how funds are utilized. Our system ensures transparency, accountability, and corruption risk detection."

### Demo Flow (3 minutes)
1. **Dashboard Overview** - Show admin analytics (30s)
2. **Red Flag Detection** - Live demo of risk alert (45s)
3. **Map Visualization** - Interactive project exploration (45s)
4. **Citizen Complaint** - Submit and track complaint (45s)
5. **GPS Verification** - Show geotagged validation (15s)

### Closing (30 seconds)
> "PETMS is not just a monitoring tool—it's a citizen empowerment platform that can integrate with existing PFMS systems via API, making government spending transparent for 1.4 billion Indians."

---

## 🏆 Why This Wins

✅ **Strong Social Impact** - Directly addresses corruption and transparency  
✅ **Government Relevance** - Aligns with Digital India initiative  
✅ **Technical Depth** - Rule-based AI, GPS verification, automated alerts  
✅ **Production-Ready UI** - Clean, professional, responsive design  
✅ **Scalability** - Can integrate with PFMS, extend to all states  
✅ **Innovation** - Social auditing + geotagged verification is unique  

---

## 📸 Screenshots

_Add screenshots here after implementation_

---

## 🤝 Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

---

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## 📧 Contact

**Project Team:**
- Lead Developer - [@yourhandle](https://github.com/yourhandle)
- Email - team@petms.example.com

**Project Link:** [https://github.com/yourusername/petms](https://github.com/yourusername/petms)

---

## 🙏 Acknowledgments

- Smart India Hackathon organizers
- Anthropic Claude for development assistance
- OpenStreetMap for mapping data
- MongoDB Atlas for database hosting

---

<div align="center">

**Built with ❤️ for transparent governance in India**

[Demo](https://petms-demo.vercel.app) · [Report Bug](https://github.com/yourusername/petms/issues) · [Request Feature](https://github.com/yourusername/petms/issues)

</div>
