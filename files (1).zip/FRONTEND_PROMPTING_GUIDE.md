# 🎨 PETMS Frontend Development Guide

## 📋 Complete Prompting File for Frontend Development

This document contains all the prompts you need to build the PETMS frontend using Claude or any AI coding assistant.

---

## 🎯 Initial Setup Prompt

```
Create a React 18 project for PETMS (Public Expenditure Transparency & Monitoring System) with the following setup:

TECH STACK:
- React 18.x with Vite
- Tailwind CSS for styling
- Shadcn/ui for components
- Recharts for data visualization
- React Router v6 for routing
- Leaflet with react-leaflet for maps
- Lucide React for icons
- Zustand for state management
- Axios for API calls

PROJECT STRUCTURE:
frontend/
├── public/
├── src/
│   ├── assets/               # Images, icons, logos
│   ├── components/           
│   │   ├── common/           # Shared components (Button, Card, Input, etc.)
│   │   ├── layout/           # Layout components (Navbar, Sidebar, Footer)
│   │   ├── admin/            # Admin-specific components
│   │   ├── contractor/       # Contractor-specific components
│   │   └── citizen/          # Citizen-specific components
│   ├── pages/                
│   │   ├── auth/             # Login pages for 3 roles
│   │   ├── admin/            # Admin dashboard and pages
│   │   ├── contractor/       # Contractor dashboard and pages
│   │   └── citizen/          # Citizen dashboard and pages
│   ├── hooks/                # Custom React hooks
│   │   ├── useAuth.js
│   │   ├── useProject.js
│   │   └── useComplaint.js
│   ├── utils/                # Helper functions
│   │   ├── formatters.js     # Currency, date formatting
│   │   ├── validators.js     # Form validation
│   │   └── constants.js      # App constants
│   ├── services/             # API integration
│   │   ├── api.js            # Axios instance
│   │   ├── auth.service.js
│   │   ├── project.service.js
│   │   └── complaint.service.js
│   ├── store/                # Zustand stores
│   │   ├── authStore.js
│   │   └── projectStore.js
│   ├── config/               # Configuration
│   │   └── routes.js         # Route definitions
│   ├── App.jsx               
│   └── main.jsx              
├── .env.example
├── package.json
├── tailwind.config.js
├── vite.config.js
└── README.md

CONFIGURATION FILES:

1. tailwind.config.js - Include custom colors for 3 roles:
   - Admin: blue (#3B82F6)
   - Contractor: orange (#F59E0B)
   - Citizen: green (#10B981)

2. .env.example:
   VITE_API_URL=http://localhost:5000/api
   VITE_MAPBOX_TOKEN=your_token_here

3. Install these packages:
   npm install react-router-dom recharts leaflet react-leaflet zustand axios lucide-react

   For Shadcn/ui:
   npx shadcn-ui@latest init
   npx shadcn-ui@latest add button card input label select textarea badge alert dialog table

Generate the complete folder structure and configuration files.
```

---

## 🔐 Authentication Pages Prompt

```
Create 3 separate login pages for PETMS with the following specifications:

COMMON FEATURES FOR ALL LOGIN PAGES:
- Centered card layout with max-width of 400px
- Logo/icon at the top
- Clean, modern design
- Form validation (email format, password min 6 chars)
- Loading state on submit
- Error message display
- "Forgot Password?" link (non-functional for now)
- Redirect to respective dashboard after login

PAGE 1: ADMIN LOGIN (/admin/login)
File: src/pages/auth/AdminLogin.jsx

DESIGN:
- Background: Gradient from blue-50 to blue-100
- Card: White with blue-500 border-top (4px)
- Header: "Admin Portal" with shield icon
- Primary button: bg-blue-600 hover:bg-blue-700
- Accent color: Blue theme throughout

FORM FIELDS:
- Email input with mail icon
- Password input with lock icon and toggle visibility
- "Remember me" checkbox
- "Login as Admin" button

DEFAULT CREDENTIALS (for demo):
- Email: admin@petms.gov.in
- Password: Admin@123

---

PAGE 2: CONTRACTOR LOGIN (/contractor/login)
File: src/pages/auth/ContractorLogin.jsx

DESIGN:
- Background: Gradient from orange-50 to orange-100
- Card: White with orange-500 border-top (4px)
- Header: "Contractor Portal" with hard-hat icon
- Primary button: bg-orange-600 hover:bg-orange-700
- Accent color: Orange theme throughout

FORM FIELDS:
- Same as admin but orange theme
- "Login as Contractor" button

DEFAULT CREDENTIALS:
- Email: contractor@example.com
- Password: Contractor@123

---

PAGE 3: CITIZEN LOGIN (/citizen/login)
File: src/pages/auth/CitizenLogin.jsx

DESIGN:
- Background: Gradient from green-50 to green-100
- Card: White with green-500 border-top (4px)
- Header: "Citizen Portal" with user icon
- Primary button: bg-green-600 hover:bg-green-700
- Accent color: Green theme throughout

FORM FIELDS:
- Same as admin but green theme
- "Login as Citizen" button
- Additional: "New Citizen? Register" link

DEFAULT CREDENTIALS:
- Email: citizen@example.com
- Password: Citizen@123

---

SHARED COMPONENT:
Create src/components/common/FormInput.jsx for reusable input fields with:
- Label
- Icon (optional)
- Error message display
- Focus states
- Accessibility (proper aria labels)

AUTHENTICATION LOGIC:
Create src/services/auth.service.js with:
- login(email, password, role)
- logout()
- getCurrentUser()
- Store JWT token in localStorage
- Set axios default authorization header

Create src/store/authStore.js (Zustand) with:
- user: null
- isAuthenticated: false
- role: null
- login(userData)
- logout()
- checkAuth()

ROUTING:
In App.jsx, set up routes:
- /admin/login → AdminLogin
- /contractor/login → ContractorLogin
- /citizen/login → CitizenLogin
- / → Redirect to /citizen/login (default)

Add ProtectedRoute component to prevent unauthorized access.

Generate all these files with complete, production-ready code.
```

---

## 📊 Admin Dashboard Prompt

```
Create a comprehensive Admin Dashboard for PETMS with the following specifications:

FILE: src/pages/admin/AdminDashboard.jsx

LAYOUT STRUCTURE:
┌─────────────────────────────────────────────────────┐
│  Sidebar  │         Main Content Area              │
│           │                                         │
│  - Logo   │  Header (Welcome + Stats Cards)        │
│  - Nav    │  ┌────────────────────────────────┐   │
│  - Links  │  │ Projects Table                 │   │
│           │  └────────────────────────────────┘   │
│           │  ┌────────────────────────────────┐   │
│           │  │ Analytics Charts               │   │
│           │  └────────────────────────────────┘   │
│           │  ┌────────────────────────────────┐   │
│           │  │ Risk Alerts Panel              │   │
│           │  └────────────────────────────────┘   │
└─────────────────────────────────────────────────────┘

---

COMPONENT BREAKDOWN:

1. SIDEBAR (src/components/layout/AdminSidebar.jsx)
- Fixed left sidebar (w-64)
- Logo at top with "PETMS Admin"
- Navigation items:
  * Dashboard (LayoutDashboard icon) - /admin/dashboard
  * All Projects (FolderKanban icon) - /admin/projects
  * Add Project (PlusCircle icon) - /admin/projects/new
  * Complaints (AlertCircle icon) - /admin/complaints
  * Analytics (BarChart3 icon) - /admin/analytics
  * Settings (Settings icon) - /admin/settings
- Active state: bg-blue-100, text-blue-700
- Logout button at bottom

---

2. HEADER SECTION
- Welcome message: "Welcome back, Admin Name"
- Current date and time
- Notification bell icon with badge (red dot for unread)
- Profile dropdown with avatar

---

3. STATS CARDS (4 cards in a grid)
Create src/components/admin/StatsCard.jsx

Card 1: Total Budget Allocated
- Icon: IndianRupee (blue)
- Value: ₹1,245 Cr
- Subtext: "+12% from last month"
- Background: Light blue gradient

Card 2: Total Budget Spent
- Icon: TrendingUp (green)
- Value: ₹892 Cr
- Subtext: "71.6% utilization"
- Progress bar showing 71.6%
- Background: Light green gradient

Card 3: Active Projects
- Icon: Folder (orange)
- Value: 47
- Subtext: "12 completed this month"
- Background: Light orange gradient

Card 4: High Risk Projects
- Icon: AlertTriangle (red)
- Value: 8
- Subtext: "Requires immediate attention"
- Pulsing red badge animation
- Background: Light red gradient

---

4. PROJECTS TABLE
Create src/components/admin/ProjectsTable.jsx

COLUMNS:
- Project Name (with department badge)
- Location (with pin icon)
- Budget (₹ formatted)
- Amount Spent (with progress bar)
- Completion % (circular progress)
- Status (badge: On Time/Delayed)
- Risk Flag (⚠️ icon if flagged)
- Actions (View, Edit icons)

FEATURES:
- Search bar at top
- Filter dropdown (Department, Status, Risk Level)
- Pagination (10 per page)
- Sort by clicking column headers
- Hover effects on rows
- Click row to view details

TABLE STYLING:
- Sticky header
- Alternating row colors
- Status badges:
  * On Time: green
  * Delayed: yellow
  * Critical: red

SAMPLE DATA (15-20 projects):
Include realistic Indian projects like:
- "Mumbai-Pune Expressway Phase 2" (Roads)
- "AIIMS Nagpur Construction" (Healthcare)
- "Smart City Bhopal - Phase 1" (Smart City)
- "Rural School Development - Bihar" (Education)

---

5. ANALYTICS SECTION
Create src/components/admin/AnalyticsCharts.jsx

3 charts in a grid (responsive):

CHART 1: PIE CHART - Budget Allocation by Department
- Use Recharts PieChart
- Segments:
  * Roads & Infrastructure: 35% (blue)
  * Healthcare: 25% (red)
  * Education: 20% (green)
  * Smart City: 15% (purple)
  * Others: 5% (gray)
- Interactive tooltips with ₹ values
- Legend at bottom

CHART 2: BAR CHART - Top 5 Projects by Spending
- Use Recharts BarChart
- X-axis: Project names (abbreviated)
- Y-axis: Amount in Crores
- Color-coded by risk level
- Tooltips showing full details

CHART 3: LINE CHART - Monthly Spending Trends
- Use Recharts LineChart
- X-axis: Last 6 months
- Y-axis: Amount in Crores
- Two lines:
  * Allocated (dashed blue)
  * Spent (solid green)
- Show divergence areas

---

6. RISK ALERTS PANEL
Create src/components/admin/RiskAlertsPanel.jsx

DESIGN:
- Card with red border
- Header: "⚠️ High Priority Alerts"
- Scrollable list (max-height: 300px)

ALERT ITEMS (5-8 alerts):
Each alert shows:
- Project name (bold)
- Risk reason (icon + text):
  * 💰 "Spent 95% but only 40% complete"
  * ⏰ "Delayed by 45 days"
  * 📈 "Budget increased by 25%"
  * 📍 "GPS verification failed"
- Timestamp (e.g., "2 hours ago")
- "Investigate" button (red, small)

INTERACTIONS:
- Click alert to open project details modal
- Mark as reviewed (checkmark icon)
- Priority badge (High/Medium/Low)

---

RESPONSIVE DESIGN:
- Desktop: Sidebar + Main content
- Tablet: Collapsible sidebar
- Mobile: Bottom navigation bar, stacked cards

STATE MANAGEMENT:
Use Zustand store (src/store/projectStore.js):
- projects: []
- stats: {}
- riskAlerts: []
- fetchProjects()
- fetchStats()
- fetchRiskAlerts()

API INTEGRATION:
Create src/services/project.service.js:
- getProjects(filters)
- getProjectStats()
- getRiskAlerts()
- updateProject(id, data)

LOADING STATES:
- Show skeleton loaders for cards
- Shimmer effect for table rows
- Spinner for charts

ERROR HANDLING:
- Toast notifications for errors
- Fallback UI if data fails to load

Generate all components with complete code, proper TypeScript types (optional), and accessibility features.
```

---

## 👷 Contractor Dashboard Prompt

```
Create a Contractor Dashboard for PETMS with the following specifications:

FILE: src/pages/contractor/ContractorDashboard.jsx

LAYOUT:
Similar to Admin but with orange theme and contractor-specific features.

---

COMPONENT BREAKDOWN:

1. SIDEBAR (src/components/layout/ContractorSidebar.jsx)
- Orange accent color (#F59E0B)
- Navigation:
  * Dashboard (Home icon)
  * My Projects (Briefcase icon)
  * Update Progress (Upload icon)
  * Reports (FileText icon)
  * Profile (User icon)

---

2. STATS CARDS (4 cards)

Card 1: My Projects
- Value: 5
- Icon: Briefcase
- Subtext: "2 active, 3 completed"

Card 2: Total Assigned Budget
- Value: ₹245 Cr
- Icon: IndianRupee
- Progress bar showing allocation

Card 3: Completion Rate
- Value: 68%
- Icon: TrendingUp
- Circular progress indicator

Card 4: Pending Updates
- Value: 3
- Icon: AlertCircle
- Pulsing orange badge

---

3. MY PROJECTS SECTION
Create src/components/contractor/ProjectCard.jsx

CARD LAYOUT (Grid of cards):
┌──────────────────────────────────┐
│  Project Name + Location         │
│  ───────────────────────────     │
│  Budget: ₹50 Cr                  │
│  Spent: ₹35 Cr (70%)             │
│  [Progress Bar ━━━━━━━━──] 70%  │
│  Completion: 65%                 │
│  Deadline: 15 days left          │
│  ───────────────────────────     │
│  [Update Progress] [View Details]│
└──────────────────────────────────┘

CARD FEATURES:
- Color-coded border based on status:
  * Green: On track
  * Yellow: Deadline approaching (<30 days)
  * Red: Delayed or flagged
- Risk badge if flagged (⚠️)
- Payment status indicator
- Last update timestamp

SAMPLE PROJECTS:
1. "NH-44 Road Widening - Hyderabad"
   - Budget: ₹85 Cr, Spent: ₹60 Cr
   - Completion: 72%
   - Status: On Track

2. "District Hospital - Jaipur"
   - Budget: ₹45 Cr, Spent: ₹42 Cr
   - Completion: 55%
   - Status: High Risk (spent 93%, only 55% done)

---

4. UPDATE PROGRESS FORM
Create src/components/contractor/ProgressUpdateForm.jsx

FORM LAYOUT:
┌────────────────────────────────────┐
│  Update Project Progress           │
│                                    │
│  Select Project: [Dropdown]        │
│                                    │
│  Completion %: [Slider 0-100]      │
│  Current: 65% ━━━━━━━━━━── 65%    │
│                                    │
│  Amount Spent: ₹ [Input]           │
│                                    │
│  Upload Photos: [Drag & Drop]      │
│  📷 GPS-tagged photos required     │
│  ⚠️ Photos must be within 5km of   │
│      project location              │
│                                    │
│  Notes: [Textarea]                 │
│  Describe progress made...         │
│                                    │
│  [Cancel] [Submit Update]          │
└────────────────────────────────────┘

VALIDATION RULES:
- Completion % cannot decrease
- Amount spent cannot exceed total budget
- At least 1 photo required
- Photos must have EXIF GPS data
- Photos must be within 5km of project coordinates

PHOTO UPLOAD:
- Show preview after upload
- Display GPS coordinates extracted
- Show distance from project site
- Green checkmark if valid, red X if too far
- Max 5 photos per update

GPS VALIDATION LOGIC:
```javascript
function validateGPSLocation(photoGPS, projectGPS, maxDistanceKM = 5) {
  const distance = calculateDistance(photoGPS, projectGPS);
  return {
    isValid: distance <= maxDistanceKM,
    distance: distance.toFixed(2),
    message: distance <= maxDistanceKM 
      ? `✓ Valid (${distance.toFixed(2)} km from site)`
      : `✗ Too far (${distance.toFixed(2)} km from site)`
  };
}
```

---

5. RECENT UPDATES TIMELINE
Create src/components/contractor/UpdatesTimeline.jsx

TIMELINE LAYOUT:
┌────────────────────────────────────┐
│  Recent Progress Updates           │
│                                    │
│  ● 2 hours ago                     │
│    Updated "NH-44 Widening"        │
│    Completion: 65% → 70%           │
│    Photos: 3 uploaded              │
│                                    │
│  ● 2 days ago                      │
│    Updated "District Hospital"     │
│    Completion: 50% → 55%           │
│    Amount spent: +₹5 Cr            │
│                                    │
│  ● 5 days ago                      │
│    Updated "Smart City Phase 1"    │
│    Completion: 80% → 85%           │
│    Status: Approved ✓              │
└────────────────────────────────────┘

TIMELINE FEATURES:
- Color-coded dots (green: approved, yellow: pending, red: rejected)
- Click to expand details
- Show approval status
- Admin comments if any

---

6. PAYMENT TRANCHE STATUS
Create src/components/contractor/PaymentStatus.jsx

TABLE:
┌──────────────────────────────────────────────────┐
│ Tranche | Amount    | Due Date  | Status         │
├──────────────────────────────────────────────────┤
│ 1       | ₹20 Cr    | Jan 2025  | ✓ Paid         │
│ 2       | ₹20 Cr    | Mar 2025  | ⏳ Pending     │
│ 3       | ₹20 Cr    | Jun 2025  | 🔒 Locked      │
│ 4       | ₹25 Cr    | Sep 2025  | 🔒 Locked      │
└──────────────────────────────────────────────────┘

PAYMENT LOGIC:
- Next tranche unlocks when:
  * Previous tranche paid
  * Progress milestone reached
  * No active red flags
- Show reason if locked: "Complete 75% to unlock"

---

RESPONSIVE DESIGN:
- Mobile: Vertical card stack
- Tablet: 2-column grid
- Desktop: 3-column grid + sidebar

STATE MANAGEMENT:
Create src/store/contractorStore.js:
- myProjects: []
- recentUpdates: []
- pendingCount: 0
- fetchMyProjects()
- submitProgressUpdate(data)

API SERVICES:
Create src/services/contractor.service.js:
- getMyProjects()
- submitProgress(projectId, formData)
- uploadPhotosWithGPS(files)
- getRecentUpdates()

Generate complete code with file upload handling, GPS extraction, and validation.
```

---

## 👤 Citizen Dashboard Prompt

```
Create a Citizen Dashboard for PETMS with public monitoring features:

FILE: src/pages/citizen/CitizenDashboard.jsx

THEME: Green (#10B981)

---

LAYOUT SECTIONS:

1. HERO SECTION
┌────────────────────────────────────────┐
│  🏛️ Public Expenditure Monitoring      │
│                                        │
│  Track government projects in your area│
│                                        │
│  [Search Projects...] [🔍]             │
│                                        │
│  Filters: [Department ▼] [Status ▼]   │
│           [Location ▼]                 │
└────────────────────────────────────────┘

---

2. STATISTICS BANNER
┌────────────────────────────────────────┐
│  ₹1,245 Cr      47 Projects      8     │
│  Monitored      Active           Flagged│
└────────────────────────────────────────┘

---

3. INTERACTIVE MAP (Primary Feature)
Create src/components/citizen/ProjectMap.jsx

MAP SPECIFICATIONS:
- Full-width leaflet map (height: 500px)
- Center on user's location (if permission granted)
- Fallback: Center on India (coordinates: 20.5937, 78.9629)

MARKER SYSTEM:
- 🟢 Green: On track projects
- 🟡 Yellow: Delayed projects
- 🔴 Red: High-risk flagged projects

MARKER POPUP (on click):
┌──────────────────────────────┐
│  Project Name                │
│  Location: City, State       │
│  Budget: ₹50 Cr              │
│  Spent: ₹35 Cr (70%)         │
│  Completion: 65%             │
│  Status: On Track            │
│  ──────────────────────      │
│  [View Details] [Raise Issue]│
└──────────────────────────────┘

MAP CONTROLS:
- Zoom in/out
- Locate me button
- Layer toggle (Satellite/Street)
- Cluster markers if too many in one area

---

4. PROJECTS GALLERY
Create src/components/citizen/ProjectGallery.jsx

GRID LAYOUT (3 columns):
┌─────────────┐ ┌─────────────┐ ┌─────────────┐
│ 🖼️ Image    │ │ 🖼️ Image    │ │ 🖼️ Image    │
│ Project A   │ │ Project B   │ │ Project C   │
│ ━━━━━━━ 70% │ │ ━━━━━━━ 85% │ │ ━━━━━── 45% │
│ ₹50 Cr      │ │ ₹80 Cr      │ │ ₹35 Cr      │
│ [Details]   │ │ [Details]   │ │ [Details]   │
└─────────────┘ └─────────────┘ └─────────────┘

CARD FEATURES:
- Project thumbnail image
- Department badge (top-right)
- Progress bar with percentage
- Budget vs Spent comparison
- Risk badge if flagged
- Upvote count (❤️ 234)
- "View Details" button

FILTERING:
- Search by name/location
- Filter by department
- Filter by status (All/On Track/Delayed/Flagged)
- Sort by: Newest, Budget, Completion

---

5. PROJECT DETAILS MODAL
Create src/components/citizen/ProjectDetailsModal.jsx

MODAL LAYOUT:
┌────────────────────────────────────────────────┐
│  ✕ Close                                       │
│                                                │
│  Project Name                                  │
│  Department Badge  |  Status Badge             │
│                                                │
│  📍 Location: Full Address                     │
│  📅 Timeline: Jan 2024 - Dec 2025              │
│                                                │
│  Budget Breakdown:                             │
│  ┌──────────────────────────────────┐         │
│  │ Allocated: ₹50 Cr                │         │
│  │ Released:  ₹50 Cr (100%)         │         │
│  │ Spent:     ₹35 Cr (70%)          │         │
│  │ Remaining: ₹15 Cr (30%)          │         │
│  └──────────────────────────────────┘         │
│                                                │
│  [Pie Chart: Budget Distribution]              │
│                                                │
│  Timeline Progress:                            │
│  Jan 2024 ━━━━●━━━━ Dec 2025                  │
│  Started       Current  Expected End           │
│                                                │
│  Contractor: ABC Construction Ltd.             │
│  Contact: +91-9876543210                       │
│                                                │
│  Recent Updates: (Timeline from contractor)    │
│  ● 2 days ago - 70% complete                   │
│  ● 10 days ago - 65% complete                  │
│                                                │
│  Citizen Reports: (5)                          │
│  ● "Work quality is poor" - 45 upvotes         │
│  ● "Materials substandard" - 32 upvotes        │
│                                                │
│  [Raise Complaint] [Download Report PDF]       │
└────────────────────────────────────────────────┘

---

6. COMPLAINT/REPORT FORM
Create src/components/citizen/ComplaintForm.jsx

FORM:
┌────────────────────────────────────┐
│  Raise a Concern                   │
│                                    │
│  Project: [Dropdown - searchable]  │
│                                    │
│  Issue Type:                       │
│  ( ) Poor Quality                  │
│  ( ) Work Stopped                  │
│  ( ) Budget Misuse                 │
│  ( ) Timeline Delay                │
│  ( ) Other                         │
│                                    │
│  Description:                      │
│  [Textarea - min 50 chars]         │
│                                    │
│  Upload Evidence:                  │
│  📷 [Drag & Drop or Click]         │
│  (Max 3 photos)                    │
│                                    │
│  📍 Capture Location               │
│  [Auto-detect GPS] or [Manual]     │
│                                    │
│  [ ] I verify this is accurate     │
│                                    │
│  [Cancel] [Submit Report]          │
└────────────────────────────────────┘

VALIDATION:
- Description minimum 50 characters
- At least 1 photo required
- GPS location mandatory
- Captcha to prevent spam

SUBMISSION:
- Show success message
- Assign tracking ID (e.g., #CMP2025001)
- Email confirmation to citizen
- Add to "My Complaints" list

---

7. MY COMPLAINTS SECTION
Create src/components/citizen/MyComplaints.jsx

LIST VIEW:
┌────────────────────────────────────────────────┐
│  My Reports & Complaints                       │
│                                                │
│  #CMP2025003 | NH-44 Road Widening             │
│  Issue: Poor Quality                           │
│  Submitted: 2 days ago                         │
│  Status: 🟡 Under Review                       │
│  Upvotes: 45 | Views: 234                      │
│  [View Details]                                │
│  ─────────────────────────────────────────     │
│  #CMP2025001 | District Hospital               │
│  Issue: Work Stopped                           │
│  Submitted: 1 week ago                         │
│  Status: 🟢 Resolved                           │
│  Admin Reply: "Work resumed, penalty imposed"  │
│  [View Details]                                │
└────────────────────────────────────────────────┘

STATUS BADGES:
- 🔴 Pending: Red
- 🟡 Under Review: Yellow
- 🟢 Resolved: Green
- ⚫ Closed: Gray

INTERACTIONS:
- Click to view full details
- See admin responses
- View photo evidence
- Share complaint link
- Upvote other citizens' complaints

---

8. UPVOTE SYSTEM
Create src/components/citizen/UpvoteButton.jsx

COMPONENT:
❤️ 234 upvotes

LOGIC:
- Click to upvote (heart fills)
- Click again to remove upvote
- Show tooltip: "234 citizens agree"
- Upvote count updates in real-time
- Highlight if current user upvoted

CRITICAL THRESHOLD:
- If complaint gets 100+ upvotes:
  * Badge changes to "⚠️ Critical"
  * Notification sent to admin
  * Priority escalated

---

9. SOCIAL AUDITING FEED
Create src/components/citizen/SocialFeed.jsx

FEED LAYOUT:
┌────────────────────────────────────────┐
│  Community Updates                     │
│                                        │
│  👤 Rajesh Kumar                       │
│     2 hours ago                        │
│     Reported issue at "Smart City"     │
│     "Work quality doesn't match specs" │
│     📷 📷 [2 photos]                   │
│     ❤️ 12 upvotes | 💬 3 comments      │
│     [Upvote] [Comment]                 │
│  ──────────────────────────────────    │
│  👤 Priya Sharma                       │
│     5 hours ago                        │
│     Progress update on "NH-44"         │
│     "Work looks good, on schedule!"    │
│     📷 [1 photo]                       │
│     ❤️ 45 upvotes | 💬 8 comments      │
│     [Upvote] [Comment]                 │
└────────────────────────────────────────┘

FEATURES:
- Infinite scroll
- Real-time updates
- Comment threads
- Photo gallery
- Share to social media
- Report spam/abuse

---

RESPONSIVE DESIGN:
- Mobile: Single column, map collapses to 300px
- Tablet: 2-column gallery
- Desktop: 3-column gallery, full map

STATE MANAGEMENT:
Create src/store/citizenStore.js:
- projects: []
- complaints: []
- selectedProject: null
- submitComplaint(data)
- upvoteComplaint(id)

API SERVICES:
Create src/services/citizen.service.js:
- getPublicProjects(filters)
- getProjectDetails(id)
- submitComplaint(formData)
- getMyComplaints()
- upvoteComplaint(id)

ACCESSIBILITY:
- ARIA labels for map markers
- Keyboard navigation for gallery
- Screen reader support for charts
- High contrast mode option

Generate complete code with all components, map integration, and form handling.
```

---

## 🗺️ Map Integration Prompt

```
Create an interactive map component using Leaflet for PETMS:

FILE: src/components/common/ProjectMap.jsx

REQUIREMENTS:

1. SETUP:
npm install leaflet react-leaflet
Add CSS in main.jsx: import 'leaflet/dist/leaflet.css'

2. MAP CONFIGURATION:
- Center: [20.5937, 78.9629] (India center)
- Zoom: 5 (country view) to 15 (city view)
- Tile Layer: OpenStreetMap
- Attribution: OpenStreetMap contributors

3. CUSTOM MARKERS:
Create color-coded marker icons:

```javascript
import L from 'leaflet';

const greenIcon = L.icon({
  iconUrl: '/markers/green-marker.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
});

const yellowIcon = L.icon({
  iconUrl: '/markers/yellow-marker.png',
  iconSize: [25, 41],
});

const redIcon = L.icon({
  iconUrl: '/markers/red-marker.png',
  iconSize: [25, 41],
});
```

4. MARKER LOGIC:
```javascript
function getMarkerIcon(project) {
  if (project.riskFlag) return redIcon;
  if (project.status === 'Delayed') return yellowIcon;
  return greenIcon;
}
```

5. POPUP CONTENT:
```jsx
<Popup>
  <div className="p-2 min-w-[200px]">
    <h3 className="font-bold text-sm">{project.title}</h3>
    <p className="text-xs text-gray-600">{project.location}</p>
    <div className="mt-2 space-y-1">
      <p className="text-xs">Budget: ₹{formatCurrency(project.totalBudget)}</p>
      <p className="text-xs">Spent: ₹{formatCurrency(project.amountSpent)}</p>
      <div className="w-full bg-gray-200 rounded h-2 mt-1">
        <div 
          className="bg-blue-500 h-2 rounded"
          style={{ width: `${project.completionPercentage}%` }}
        />
      </div>
      <p className="text-xs">{project.completionPercentage}% Complete</p>
    </div>
    <div className="mt-2 flex gap-2">
      <button className="text-xs bg-blue-500 text-white px-2 py-1 rounded">
        View Details
      </button>
      <button className="text-xs bg-green-500 text-white px-2 py-1 rounded">
        Raise Issue
      </button>
    </div>
  </div>
</Popup>
```

6. MAP CONTROLS:
- Zoom control (top-left)
- Layer control (satellite/street toggle)
- Locate me button (bottom-right)
- Fullscreen button

7. CLUSTERING (for many markers):
npm install react-leaflet-cluster

```jsx
import MarkerClusterGroup from 'react-leaflet-cluster';

<MarkerClusterGroup>
  {projects.map(project => (
    <Marker 
      key={project._id}
      position={[project.latitude, project.longitude]}
      icon={getMarkerIcon(project)}
    >
      <Popup>{/* popup content */}</Popup>
    </Marker>
  ))}
</MarkerClusterGroup>
```

8. SAMPLE PROJECT DATA (with GPS coordinates):

```javascript
const sampleProjects = [
  {
    _id: '1',
    title: 'Mumbai-Pune Expressway Phase 2',
    location: 'Maharashtra',
    latitude: 19.0760,
    longitude: 72.8777,
    totalBudget: 5000000000,
    amountSpent: 3500000000,
    completionPercentage: 70,
    status: 'On Time',
    riskFlag: false,
  },
  {
    _id: '2',
    title: 'AIIMS Nagpur',
    location: 'Nagpur, Maharashtra',
    latitude: 21.1458,
    longitude: 79.0882,
    totalBudget: 4500000000,
    amountSpent: 4200000000,
    completionPercentage: 55,
    status: 'Delayed',
    riskFlag: true,
  },
  // Add 15-20 more across India
];
```

9. GEOLOCATION:
```javascript
const handleLocateMe = () => {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        mapRef.current.flyTo([latitude, longitude], 13);
      },
      (error) => {
        toast.error('Location access denied');
      }
    );
  }
};
```

10. FILTERS:
Add filter panel above map:
- Department filter
- Status filter (All/On Track/Delayed/Flagged)
- Budget range slider

Generate complete map component with all features.
```

---

## 📈 Charts & Analytics Prompt

```
Create data visualization components using Recharts:

INSTALL:
npm install recharts

---

COMPONENT 1: PIE CHART - Budget by Department
FILE: src/components/charts/BudgetPieChart.jsx

```jsx
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const data = [
  { name: 'Roads & Infrastructure', value: 35, amount: 43625000000 },
  { name: 'Healthcare', value: 25, amount: 31125000000 },
  { name: 'Education', value: 20, amount: 24900000000 },
  { name: 'Smart City', value: 15, amount: 18675000000 },
  { name: 'Others', value: 5, amount: 6225000000 },
];

const COLORS = ['#3B82F6', '#EF4444', '#10B981', '#8B5CF6', '#6B7280'];

export default function BudgetPieChart() {
  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h3 className="text-lg font-semibold mb-4">Budget Allocation by Department</h3>
      <ResponsiveContainer width="100%" height={300}>
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            labelLine={false}
            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
            outerRadius={100}
            fill="#8884d8"
            dataKey="value"
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip 
            formatter={(value, name, props) => [
              `₹${(props.payload.amount / 10000000).toFixed(0)} Cr (${value}%)`,
              props.payload.name
            ]}
          />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
```

---

COMPONENT 2: BAR CHART - Top Projects by Spending
FILE: src/components/charts/TopProjectsBarChart.jsx

```jsx
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const data = [
  { name: 'Mumbai-Pune Exp.', spent: 350, budget: 500, risk: false },
  { name: 'AIIMS Nagpur', spent: 420, budget: 450, risk: true },
  { name: 'Smart City Bhopal', spent: 280, budget: 400, risk: false },
  { name: 'Rural Schools Bihar', spent: 150, budget: 200, risk: false },
  { name: 'Delhi Metro Phase 4', spent: 780, budget: 900, risk: false },
];

export default function TopProjectsBarChart() {
  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h3 className="text-lg font-semibold mb-4">Top 5 Projects by Spending</h3>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" angle={-15} textAnchor="end" height={80} />
          <YAxis label={{ value: 'Amount (₹ Cr)', angle: -90, position: 'insideLeft' }} />
          <Tooltip 
            formatter={(value) => `₹${value} Cr`}
            labelStyle={{ color: '#000' }}
          />
          <Legend />
          <Bar dataKey="spent" fill="#10B981" name="Amount Spent" />
          <Bar dataKey="budget" fill="#3B82F6" name="Total Budget" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
```

---

COMPONENT 3: LINE CHART - Monthly Trends
FILE: src/components/charts/MonthlyTrendsChart.jsx

```jsx
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const data = [
  { month: 'Aug 2024', allocated: 200, spent: 150 },
  { month: 'Sep 2024', allocated: 220, spent: 170 },
  { month: 'Oct 2024', allocated: 240, spent: 190 },
  { month: 'Nov 2024', allocated: 260, spent: 210 },
  { month: 'Dec 2024', allocated: 280, spent: 225 },
  { month: 'Jan 2025', allocated: 300, spent: 245 },
];

export default function MonthlyTrendsChart() {
  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h3 className="text-lg font-semibold mb-4">Monthly Spending Trends</h3>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="month" />
          <YAxis label={{ value: 'Amount (₹ Cr)', angle: -90, position: 'insideLeft' }} />
          <Tooltip formatter={(value) => `₹${value} Cr`} />
          <Legend />
          <Line 
            type="monotone" 
            dataKey="allocated" 
            stroke="#3B82F6" 
            strokeDasharray="5 5"
            name="Allocated"
            strokeWidth={2}
          />
          <Line 
            type="monotone" 
            dataKey="spent" 
            stroke="#10B981" 
            name="Spent"
            strokeWidth={2}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
```

---

COMPONENT 4: Progress Donut Chart
FILE: src/components/charts/ProgressDonut.jsx

```jsx
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';

export default function ProgressDonut({ percentage, size = 120 }) {
  const data = [
    { name: 'Complete', value: percentage },
    { name: 'Remaining', value: 100 - percentage },
  ];
  
  const COLORS = ['#10B981', '#E5E7EB'];
  
  return (
    <div className="relative inline-block" style={{ width: size, height: size }}>
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={size * 0.35}
            outerRadius={size * 0.45}
            startAngle={90}
            endAngle={-270}
            dataKey="value"
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index]} />
            ))}
          </Pie>
        </PieChart>
      </ResponsiveContainer>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-2xl font-bold">{percentage}%</span>
      </div>
    </div>
  );
}
```

Generate all chart components with responsive design and tooltips.
```

---

## 🔧 Utilities & Helpers Prompt

```
Create utility functions for PETMS frontend:

FILE 1: src/utils/formatters.js

```javascript
// Currency formatting
export const formatCurrency = (amount) => {
  if (amount >= 10000000) {
    return `₹${(amount / 10000000).toFixed(2)} Cr`;
  } else if (amount >= 100000) {
    return `₹${(amount / 100000).toFixed(2)} L`;
  } else {
    return `₹${amount.toLocaleString('en-IN')}`;
  }
};

// Date formatting
export const formatDate = (dateString) => {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
};

// Relative time (e.g., "2 hours ago")
export const formatRelativeTime = (dateString) => {
  const date = new Date(dateString);
  const now = new Date();
  const diffMs = now - date;
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);
  
  if (diffMins < 60) return `${diffMins} minutes ago`;
  if (diffHours < 24) return `${diffHours} hours ago`;
  if (diffDays < 7) return `${diffDays} days ago`;
  return formatDate(dateString);
};

// Percentage with color
export const getPercentageColor = (percentage) => {
  if (percentage >= 75) return 'text-green-600';
  if (percentage >= 50) return 'text-yellow-600';
  return 'text-red-600';
};

// Status badge color
export const getStatusBadgeColor = (status) => {
  const colors = {
    'On Time': 'bg-green-100 text-green-800',
    'Delayed': 'bg-yellow-100 text-yellow-800',
    'Critical': 'bg-red-100 text-red-800',
    'Completed': 'bg-blue-100 text-blue-800',
  };
  return colors[status] || 'bg-gray-100 text-gray-800';
};
```

---

FILE 2: src/utils/validators.js

```javascript
// Email validation
export const isValidEmail = (email) => {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email);
};

// Password validation (min 6 chars, 1 uppercase, 1 number)
export const isValidPassword = (password) => {
  return password.length >= 6;
};

// Phone number validation (Indian)
export const isValidPhone = (phone) => {
  const regex = /^[6-9]\d{9}$/;
  return regex.test(phone);
};

// Pincode validation
export const isValidPincode = (pincode) => {
  const regex = /^[1-9][0-9]{5}$/;
  return regex.test(pincode);
};

// File validation (image only, max 5MB)
export const isValidImage = (file) => {
  const validTypes = ['image/jpeg', 'image/jpg', 'image/png'];
  const maxSize = 5 * 1024 * 1024; // 5MB
  
  return validTypes.includes(file.type) && file.size <= maxSize;
};

// Form validation helper
export const validateForm = (values, rules) => {
  const errors = {};
  
  Object.keys(rules).forEach(field => {
    const rule = rules[field];
    const value = values[field];
    
    if (rule.required && !value) {
      errors[field] = `${field} is required`;
    }
    
    if (rule.minLength && value.length < rule.minLength) {
      errors[field] = `Minimum ${rule.minLength} characters required`;
    }
    
    if (rule.pattern && !rule.pattern.test(value)) {
      errors[field] = rule.message || 'Invalid format';
    }
  });
  
  return errors;
};
```

---

FILE 3: src/utils/gps.utils.js

```javascript
// Calculate distance between two GPS coordinates (Haversine formula)
export const calculateDistance = (coord1, coord2) => {
  const toRad = (value) => (value * Math.PI) / 180;
  
  const lat1 = coord1.latitude;
  const lon1 = coord1.longitude;
  const lat2 = coord2.latitude;
  const lon2 = coord2.longitude;
  
  const R = 6371; // Earth's radius in km
  
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;
  
  return distance; // in km
};

// Extract GPS from EXIF data
export const extractGPSFromFile = async (file) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      const view = new DataView(e.target.result);
      // Simplified - use exif-js library in production
      // This is a placeholder
      resolve({
        latitude: 19.0760,
        longitude: 72.8777,
      });
    };
    
    reader.onerror = reject;
    reader.readAsArrayBuffer(file.slice(0, 64 * 1024));
  });
};

// Validate GPS location
export const validateGPSLocation = (photoGPS, projectGPS, maxDistanceKM = 5) => {
  const distance = calculateDistance(photoGPS, projectGPS);
  
  return {
    isValid: distance <= maxDistanceKM,
    distance: distance.toFixed(2),
    message: distance <= maxDistanceKM 
      ? `✓ Valid (${distance.toFixed(2)} km from site)`
      : `✗ Too far (${distance.toFixed(2)} km from site - max ${maxDistanceKM} km allowed)`,
  };
};
```

---

FILE 4: src/utils/constants.js

```javascript
export const DEPARTMENTS = [
  'Roads & Infrastructure',
  'Healthcare',
  'Education',
  'Smart City',
  'Rural Development',
  'Water Supply',
  'Sanitation',
  'Energy',
  'Others',
];

export const PROJECT_STATUS = {
  ON_TIME: 'On Time',
  DELAYED: 'Delayed',
  CRITICAL: 'Critical',
  COMPLETED: 'Completed',
};

export const COMPLAINT_STATUS = {
  PENDING: 'Pending',
  UNDER_REVIEW: 'Under Review',
  RESOLVED: 'Resolved',
  CLOSED: 'Closed',
};

export const USER_ROLES = {
  ADMIN: 'admin',
  CONTRACTOR: 'contractor',
  CITIZEN: 'citizen',
};

export const RISK_THRESHOLDS = {
  BUDGET_OVERRUN: 0.9, // 90% spent
  COMPLETION_LAG: 0.5, // <50% done
  DELAY_DAYS: 30,
  BUDGET_SPIKE: 0.2, // 20% increase
  GPS_MAX_DISTANCE: 5, // km
  CRITICAL_UPVOTES: 100,
};

export const INDIAN_STATES = [
  'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar',
  'Chhattisgarh', 'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh',
  'Jharkhand', 'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra',
  'Manipur', 'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha',
  'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana',
  'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal',
];

export const CHART_COLORS = {
  primary: '#3B82F6',
  success: '#10B981',
  warning: '#F59E0B',
  danger: '#EF4444',
  purple: '#8B5CF6',
  gray: '#6B7280',
};
```

Generate all utility files with comprehensive functions.
```

---

## 📦 Final Integration Prompt

```
Create the main App.jsx with routing and authentication:

FILE: src/App.jsx

```jsx
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';

// Auth Pages
import AdminLogin from './pages/auth/AdminLogin';
import ContractorLogin from './pages/auth/ContractorLogin';
import CitizenLogin from './pages/auth/CitizenLogin';

// Admin Pages
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminProjects from './pages/admin/AdminProjects';
import AdminComplaints from './pages/admin/AdminComplaints';

// Contractor Pages
import ContractorDashboard from './pages/contractor/ContractorDashboard';
import ContractorProjects from './pages/contractor/ContractorProjects';

// Citizen Pages
import CitizenDashboard from './pages/citizen/CitizenDashboard';
import CitizenComplaints from './pages/citizen/CitizenComplaints';

// Components
import ProtectedRoute from './components/common/ProtectedRoute';
import NotFound from './pages/NotFound';

function App() {
  return (
    <BrowserRouter>
      <Toaster position="top-right" />
      
      <Routes>
        {/* Default redirect */}
        <Route path="/" element={<Navigate to="/citizen/login" replace />} />
        
        {/* Auth Routes */}
        <Route path="/admin/login" element={<AdminLogin />} />
        <Route path="/contractor/login" element={<ContractorLogin />} />
        <Route path="/citizen/login" element={<CitizenLogin />} />
        
        {/* Admin Routes */}
        <Route path="/admin" element={<ProtectedRoute role="admin" />}>
          <Route path="dashboard" element={<AdminDashboard />} />
          <Route path="projects" element={<AdminProjects />} />
          <Route path="complaints" element={<AdminComplaints />} />
        </Route>
        
        {/* Contractor Routes */}
        <Route path="/contractor" element={<ProtectedRoute role="contractor" />}>
          <Route path="dashboard" element={<ContractorDashboard />} />
          <Route path="projects" element={<ContractorProjects />} />
        </Route>
        
        {/* Citizen Routes */}
        <Route path="/citizen" element={<ProtectedRoute role="citizen" />}>
          <Route path="dashboard" element={<CitizenDashboard />} />
          <Route path="complaints" element={<CitizenComplaints />} />
        </Route>
        
        {/* 404 */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
```

---

FILE: src/components/common/ProtectedRoute.jsx

```jsx
import { Navigate, Outlet } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';

export default function ProtectedRoute({ role }) {
  const { isAuthenticated, user } = useAuthStore();
  
  if (!isAuthenticated) {
    return <Navigate to={`/${role}/login`} replace />;
  }
  
  if (user.role !== role) {
    return <Navigate to={`/${user.role}/dashboard`} replace />;
  }
  
  return <Outlet />;
}
```

---

FILE: src/store/authStore.js

```javascript
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export const useAuthStore = create(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      role: null,
      
      login: (userData) => set({
        user: userData,
        isAuthenticated: true,
        role: userData.role,
      }),
      
      logout: () => set({
        user: null,
        isAuthenticated: false,
        role: null,
      }),
      
      updateUser: (userData) => set((state) => ({
        user: { ...state.user, ...userData },
      })),
    }),
    {
      name: 'auth-storage',
    }
  )
);
```

---

FILE: src/services/api.js

```javascript
import axios from 'axios';
import { useAuthStore } from '../store/authStore';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      useAuthStore.getState().logout();
      window.location.href = '/citizen/login';
    }
    return Promise.reject(error);
  }
);

export default api;
```

Generate complete routing and authentication setup with all necessary files.
```

---

## ✅ Checklist Before Building

Before you start coding, make sure you have:

1. ✅ Node.js 18+ installed
2. ✅ MongoDB connection string ready
3. ✅ Cloudinary account (for image uploads)
4. ✅ .env files configured
5. ✅ All required packages installed
6. ✅ Tailwind CSS configured with custom colors
7. ✅ Shadcn/ui components initialized
8. ✅ Leaflet CSS imported
9. ✅ Sample data prepared (15-20 projects with GPS coordinates)
10. ✅ Image markers for map (green, yellow, red)

---

## 🚀 Quick Start Commands

```bash
# Frontend
cd frontend
npm install
npm run dev

# Backend (covered in separate file)
cd backend
npm install
npm run dev
```

---

## 📝 Development Tips

1. **Start with Authentication** - Build login pages first, test routing
2. **Mock Data First** - Use dummy data before connecting to backend
3. **Component-First Approach** - Build reusable components
4. **Mobile Responsive** - Test on different screen sizes
5. **Accessibility** - Add ARIA labels, keyboard navigation
6. **Error Handling** - Toast notifications for user feedback
7. **Loading States** - Skeleton loaders for better UX
8. **Code Organization** - Keep components small and focused
9. **Version Control** - Commit frequently with clear messages
10. **Testing** - Test user flows before integration

---

This comprehensive prompting file will help you build a production-ready PETMS frontend step by step. Use these prompts with Claude or any AI coding assistant to generate complete, working code.
