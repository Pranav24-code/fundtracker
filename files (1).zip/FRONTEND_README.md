# 🎨 PETMS Frontend

> React-based frontend for Public Expenditure Transparency & Monitoring System

## 📋 Overview

The PETMS frontend provides three role-based portals (Admin, Contractor, Citizen) with interactive dashboards, real-time project monitoring, map visualization, and complaint management.

## 🛠️ Tech Stack

- **Framework**: React 18.x + Vite
- **Styling**: Tailwind CSS
- **UI Components**: Shadcn/ui
- **Charts**: Recharts
- **Maps**: Leaflet + React-Leaflet
- **Routing**: React Router v6
- **State Management**: Zustand
- **HTTP Client**: Axios
- **Icons**: Lucide React

## 📁 Project Structure

```
frontend/
├── public/
│   └── markers/              # Map marker icons
├── src/
│   ├── assets/               # Images, logos
│   ├── components/
│   │   ├── common/           # Shared components
│   │   │   ├── Button.jsx
│   │   │   ├── Card.jsx
│   │   │   ├── FormInput.jsx
│   │   │   ├── StatsCard.jsx
│   │   │   └── ProjectMap.jsx
│   │   ├── layout/           # Layout components
│   │   │   ├── AdminSidebar.jsx
│   │   │   ├── ContractorSidebar.jsx
│   │   │   └── CitizenNavbar.jsx
│   │   ├── admin/            # Admin components
│   │   │   ├── ProjectsTable.jsx
│   │   │   ├── AnalyticsCharts.jsx
│   │   │   └── RiskAlertsPanel.jsx
│   │   ├── contractor/       # Contractor components
│   │   │   ├── ProjectCard.jsx
│   │   │   ├── ProgressUpdateForm.jsx
│   │   │   └── UpdatesTimeline.jsx
│   │   └── citizen/          # Citizen components
│   │       ├── ProjectGallery.jsx
│   │       ├── ProjectDetailsModal.jsx
│   │       ├── ComplaintForm.jsx
│   │       └── MyComplaints.jsx
│   ├── pages/
│   │   ├── auth/
│   │   │   ├── AdminLogin.jsx
│   │   │   ├── ContractorLogin.jsx
│   │   │   └── CitizenLogin.jsx
│   │   ├── admin/
│   │   │   ├── AdminDashboard.jsx
│   │   │   ├── AdminProjects.jsx
│   │   │   └── AdminComplaints.jsx
│   │   ├── contractor/
│   │   │   ├── ContractorDashboard.jsx
│   │   │   └── ContractorProjects.jsx
│   │   └── citizen/
│   │       ├── CitizenDashboard.jsx
│   │       └── CitizenComplaints.jsx
│   ├── hooks/
│   │   ├── useAuth.js
│   │   ├── useProject.js
│   │   └── useComplaint.js
│   ├── utils/
│   │   ├── formatters.js     # Currency, date formatting
│   │   ├── validators.js     # Form validation
│   │   ├── gps.utils.js      # GPS calculations
│   │   └── constants.js      # App constants
│   ├── services/
│   │   ├── api.js            # Axios instance
│   │   ├── auth.service.js
│   │   ├── project.service.js
│   │   └── complaint.service.js
│   ├── store/
│   │   ├── authStore.js      # Authentication state
│   │   └── projectStore.js   # Project state
│   ├── config/
│   │   └── routes.js
│   ├── App.jsx
│   └── main.jsx
├── .env.example
├── .gitignore
├── package.json
├── tailwind.config.js
├── vite.config.js
└── README.md
```

## 🚀 Getting Started

### Prerequisites

- Node.js 18.x or higher
- npm or yarn

### Installation

1. **Clone the repository**
```bash
git clone https://github.com/yourusername/petms.git
cd petms/frontend
```

2. **Install dependencies**
```bash
npm install
```

3. **Configure environment variables**
```bash
cp .env.example .env
```

Edit `.env`:
```env
VITE_API_URL=http://localhost:5000/api
```

4. **Start development server**
```bash
npm run dev
```

The app will be available at `http://localhost:5173`

## 🔐 Default Login Credentials

### Admin Portal
- URL: `/admin/login`
- Email: `admin@petms.gov.in`
- Password: `Admin@123`

### Contractor Portal
- URL: `/contractor/login`
- Email: `contractor@example.com`
- Password: `Contractor@123`

### Citizen Portal
- URL: `/citizen/login`
- Email: `citizen@example.com`
- Password: `Citizen@123`

## 📦 Dependencies

```json
{
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.20.0",
    "recharts": "^2.10.0",
    "leaflet": "^1.9.4",
    "react-leaflet": "^4.2.1",
    "zustand": "^4.4.7",
    "axios": "^1.6.2",
    "lucide-react": "^0.294.0",
    "react-hot-toast": "^2.4.1"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.2.0",
    "tailwindcss": "^3.3.6",
    "autoprefixer": "^10.4.16",
    "postcss": "^8.4.32",
    "vite": "^5.0.0"
  }
}
```

## 🎨 Theme Colors

```javascript
// Tailwind config
theme: {
  extend: {
    colors: {
      admin: {
        primary: '#3B82F6',
        light: '#DBEAFE',
      },
      contractor: {
        primary: '#F59E0B',
        light: '#FEF3C7',
      },
      citizen: {
        primary: '#10B981',
        light: '#D1FAE5',
      },
    },
  },
}
```

## 📱 Features by Role

### Admin Dashboard
✅ Overview statistics (budget, projects, risks)  
✅ Projects table with filtering and search  
✅ Analytics charts (pie, bar, line)  
✅ Red flag alerts panel  
✅ Complaint management  
✅ Project CRUD operations  

### Contractor Dashboard
✅ My projects overview  
✅ Progress update form with GPS validation  
✅ Payment tranche tracking  
✅ Recent updates timeline  
✅ Photo upload with EXIF extraction  

### Citizen Dashboard
✅ Interactive project map  
✅ Project gallery with filters  
✅ Complaint submission  
✅ Complaint tracking  
✅ Upvote system  
✅ Social auditing feed  

## 🗺️ Map Configuration

```javascript
// Map center (India)
const DEFAULT_CENTER = [20.5937, 78.9629];
const DEFAULT_ZOOM = 5;

// Marker colors
const MARKERS = {
  green: 'On Track',
  yellow: 'Delayed',
  red: 'High Risk',
};
```

## 📊 Chart Components

1. **Pie Chart** - Budget allocation by department
2. **Bar Chart** - Top projects by spending
3. **Line Chart** - Monthly spending trends
4. **Progress Donut** - Individual project completion

## 🔧 Utilities

### Currency Formatter
```javascript
formatCurrency(5000000000) // "₹50 Cr"
```

### Date Formatter
```javascript
formatDate("2024-01-15") // "15 Jan 2024"
formatRelativeTime("2024-02-14") // "2 days ago"
```

### GPS Distance Calculator
```javascript
calculateDistance(coord1, coord2) // Returns km
```

## 🚦 Routing Structure

```
/
├── /admin/login
├── /contractor/login
├── /citizen/login
├── /admin/
│   ├── dashboard
│   ├── projects
│   └── complaints
├── /contractor/
│   ├── dashboard
│   └── projects
└── /citizen/
    ├── dashboard
    └── complaints
```

## 🎯 State Management (Zustand)

### Auth Store
```javascript
{
  user: { id, name, email, role },
  isAuthenticated: boolean,
  login: (userData) => void,
  logout: () => void,
}
```

### Project Store
```javascript
{
  projects: [],
  selectedProject: null,
  filters: {},
  fetchProjects: () => void,
  setFilters: (filters) => void,
}
```

## 🧪 Testing

```bash
# Run tests (when configured)
npm run test

# Build for production
npm run build

# Preview production build
npm run preview
```

## 📦 Building for Production

```bash
# Create optimized build
npm run build

# Output will be in 'dist' folder
```

## 🚀 Deployment

### Vercel (Recommended)

1. **Install Vercel CLI**
```bash
npm i -g vercel
```

2. **Deploy**
```bash
vercel --prod
```

3. **Configure Environment Variables** in Vercel dashboard

### Manual Deployment

1. Build the project
```bash
npm run build
```

2. Upload `dist` folder to your hosting provider

3. Configure environment variables

## 🔒 Security Best Practices

✅ JWT tokens stored in localStorage  
✅ Protected routes with authentication check  
✅ Role-based access control  
✅ Input validation on all forms  
✅ CORS configured for API requests  
✅ No sensitive data in frontend code  

## 📝 Code Style

- **ESLint**: Code linting
- **Prettier**: Code formatting
- **Naming**: camelCase for variables, PascalCase for components
- **File structure**: Feature-based organization

## 🐛 Troubleshooting

### Map not displaying
- Check if Leaflet CSS is imported in `main.jsx`
- Verify map container has explicit height

### API calls failing
- Check `VITE_API_URL` in `.env`
- Ensure backend server is running
- Check CORS configuration

### Images not uploading
- Verify file size < 5MB
- Check allowed file types (JPEG, PNG)
- Ensure multipart/form-data header

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## 📄 License

MIT License - see LICENSE file for details

---

<div align="center">

**Built with ❤️ for transparent governance**

[Demo](https://petms-demo.vercel.app) · [Report Bug](https://github.com/yourusername/petms/issues) · [Request Feature](https://github.com/yourusername/petms/issues)

</div>
