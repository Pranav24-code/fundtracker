# ⚙️ PETMS Backend API

> Node.js REST API for Public Expenditure Transparency & Monitoring System

## 📋 Overview

The PETMS backend provides a robust REST API with JWT authentication, role-based access control, GPS validation, automated red-flag detection, and comprehensive project and complaint management.

## 🛠️ Tech Stack

- **Runtime**: Node.js 18.x
- **Framework**: Express.js 4.x
- **Database**: MongoDB (Mongoose ODM)
- **Authentication**: JWT (JSON Web Tokens)
- **File Upload**: Multer + Cloudinary
- **GPS Extraction**: EXIF Parser
- **Scheduled Jobs**: Node-cron
- **Security**: Helmet, CORS, Rate Limiting
- **Validation**: Express Validator

## 📁 Project Structure

```
backend/
├── src/
│   ├── config/
│   │   ├── database.js        # MongoDB connection
│   │   ├── cloudinary.js      # Cloudinary config
│   │   ├── constants.js       # App constants
│   │   └── env.js             # Environment validation
│   ├── models/
│   │   ├── User.js            # User schema
│   │   ├── Project.js         # Project schema
│   │   ├── Complaint.js       # Complaint schema
│   │   └── Update.js          # Progress update schema
│   ├── routes/
│   │   ├── auth.routes.js     # Authentication
│   │   ├── project.routes.js  # Project CRUD
│   │   ├── complaint.routes.js # Complaint management
│   │   └── stats.routes.js    # Analytics
│   ├── controllers/
│   │   ├── auth.controller.js
│   │   ├── project.controller.js
│   │   ├── complaint.controller.js
│   │   └── stats.controller.js
│   ├── middleware/
│   │   ├── auth.middleware.js # JWT verification
│   │   ├── upload.middleware.js # File handling
│   │   ├── validate.middleware.js # Input validation
│   │   └── error.middleware.js # Error handling
│   ├── utils/
│   │   ├── redFlag.utils.js   # Red flag detection
│   │   ├── gps.utils.js       # GPS validation
│   │   ├── email.utils.js     # Email notifications
│   │   └── response.utils.js  # API responses
│   ├── jobs/
│   │   └── redFlag.job.js     # Automated scanning
│   ├── validators/
│   │   ├── auth.validator.js
│   │   ├── project.validator.js
│   │   └── complaint.validator.js
│   ├── app.js                 # Express setup
│   └── server.js              # Server entry
├── scripts/
│   └── seed.js                # Database seeding
├── uploads/                   # Temporary file storage
├── .env.example
├── .gitignore
├── package.json
└── README.md
```

## 🚀 Getting Started

### Prerequisites

- Node.js 18.x or higher
- MongoDB (local or Atlas)
- Cloudinary account (for image storage)

### Installation

1. **Clone the repository**
```bash
git clone https://github.com/yourusername/petms.git
cd petms/backend
```

2. **Install dependencies**
```bash
npm install
```

3. **Configure environment variables**
```bash
cp .env.example .env
```

Edit `.env`:
```env
NODE_ENV=development
PORT=5000

# Database
MONGODB_URI=mongodb://localhost:27017/petms
# or Atlas:
# MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/petms

# JWT
JWT_SECRET=your_super_secret_jwt_key_change_this_in_production
JWT_EXPIRE=7d

# Cloudinary
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret

# Frontend
FRONTEND_URL=http://localhost:5173

# Red Flag Detection
MAX_GPS_DISTANCE_KM=5
RED_FLAG_SCAN_CRON=0 */6 * * *

# Email (optional)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your_email@gmail.com
SMTP_PASS=your_app_password

# Rate Limiting
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
```

4. **Seed the database** (optional)
```bash
node scripts/seed.js
```

5. **Start the server**
```bash
# Development
npm run dev

# Production
npm start
```

Server will run on `http://localhost:5000`

## 📦 Dependencies

```json
{
  "dependencies": {
    "express": "^4.18.2",
    "mongoose": "^8.0.0",
    "dotenv": "^16.3.1",
    "bcryptjs": "^2.4.3",
    "jsonwebtoken": "^9.0.2",
    "multer": "^1.4.5-lts.1",
    "cloudinary": "^1.41.0",
    "exif-parser": "^0.1.12",
    "node-cron": "^3.0.3",
    "cors": "^2.8.5",
    "helmet": "^7.1.0",
    "express-rate-limit": "^7.1.5",
    "express-validator": "^7.0.1",
    "nodemailer": "^6.9.7",
    "morgan": "^1.10.0"
  },
  "devDependencies": {
    "nodemon": "^3.0.2"
  }
}
```

## 🔐 Authentication

### Register
```http
POST /api/auth/register
Content-Type: application/json

{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "Password123",
  "role": "citizen",
  "phone": "9876543210"
}
```

### Login
```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "admin@petms.gov.in",
  "password": "Admin@123",
  "role": "admin"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "user": {
      "_id": "...",
      "name": "Admin User",
      "email": "admin@petms.gov.in",
      "role": "admin"
    },
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

## 📚 API Endpoints

### Authentication Routes (`/api/auth`)
| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| POST | `/register` | Public | Register new user |
| POST | `/login` | Public | User login |
| GET | `/me` | Private | Get current user |
| POST | `/logout` | Private | Logout user |

### Project Routes (`/api/projects`)
| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/` | Public | Get all projects (with filters) |
| GET | `/:id` | Public | Get single project |
| POST | `/` | Admin | Create project |
| PUT | `/:id` | Admin | Update project |
| DELETE | `/:id` | Admin | Delete project |
| GET | `/nearby` | Public | Get nearby projects |

### Complaint Routes (`/api/complaints`)
| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/` | Private | Get all complaints |
| GET | `/:id` | Private | Get single complaint |
| POST | `/` | Citizen | Submit complaint |
| POST | `/:id/upvote` | Citizen | Upvote complaint |
| PUT | `/:id/respond` | Admin | Respond to complaint |

### Stats Routes (`/api/stats`)
| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/overview` | Admin | Overall statistics |
| GET | `/department-allocation` | Admin | Budget by department |
| GET | `/monthly-trends` | Admin | Monthly spending trends |
| GET | `/contractor` | Contractor | Contractor statistics |

## 📊 Database Models

### User Model
```javascript
{
  name: String,
  email: String (unique),
  password: String (hashed),
  role: Enum ['admin', 'contractor', 'citizen'],
  phone: String,
  avatar: String,
  isActive: Boolean,
  lastLogin: Date,
  timestamps: true
}
```

### Project Model
```javascript
{
  title: String,
  description: String,
  department: Enum,
  location: {
    address: String,
    city: String,
    state: String,
    pincode: String,
    coordinates: { latitude, longitude }
  },
  totalBudget: Number,
  amountSpent: Number,
  completionPercentage: Number,
  startDate: Date,
  expectedEndDate: Date,
  actualEndDate: Date,
  status: Enum ['On Time', 'Delayed', 'Critical', 'Completed'],
  riskFlag: Boolean,
  riskFactors: Array,
  contractor: ObjectId (ref User),
  images: Array,
  budgetHistory: Array,
  isActive: Boolean,
  timestamps: true
}
```

### Complaint Model
```javascript
{
  project: ObjectId (ref Project),
  citizen: ObjectId (ref User),
  issueType: Enum,
  description: String,
  images: Array,
  location: { latitude, longitude },
  status: Enum ['Pending', 'Under Review', 'Resolved', 'Closed'],
  upvotes: Number,
  upvotedBy: Array (ObjectIds),
  adminResponse: {
    message: String,
    respondedBy: ObjectId,
    respondedAt: Date
  },
  trackingId: String (unique),
  isCritical: Boolean,
  timestamps: true
}
```

## 🚨 Red Flag Detection System

### Detection Logic
```javascript
// Factor 1: Budget Overrun
if (spendingPercent > 90% && completionPercent < 50%) {
  riskFactors.push('BUDGET_OVERRUN');
}

// Factor 2: Timeline Delay
if (delayDays > 30) {
  riskFactors.push('TIMELINE_DELAY');
}

// Factor 3: Budget Spike
if (budgetIncrease > 20%) {
  riskFactors.push('BUDGET_SPIKE');
}

// Factor 4: GPS Verification Failed
if (photoGPSDistance > 5km) {
  riskFactors.push('GPS_FRAUD');
}

// Factor 5: High Complaints
if (complaintCount > 50) {
  riskFactors.push('PUBLIC_CONCERN');
}
```

### Automated Scanning
- **Schedule**: Every 6 hours (configurable via cron)
- **Action**: Scans all active projects
- **Alerts**: Email notifications to admins
- **Logging**: Console output with results

## 📍 GPS Validation

### EXIF Extraction
```javascript
const gpsData = await extractGPSFromImage(filePath);
// Returns: { latitude, longitude, timestamp, hasGPS }
```

### Distance Calculation
```javascript
const distance = calculateDistance(photoGPS, projectGPS);
// Uses Haversine formula, returns distance in km
```

### Validation
```javascript
const validation = validateGPSLocation(photoGPS, projectGPS, maxKM);
// Returns: { isValid, distance, message }
```

## 📧 Email Notifications

### Red Flag Alerts
```javascript
await sendAlertEmail({
  to: 'admin@example.com',
  subject: '⚠️ Red Flag Alert',
  project: projectData,
  riskFactors: ['BUDGET_OVERRUN', 'TIMELINE_DELAY']
});
```

### Complaint Notifications
```javascript
await sendEmail({
  to: 'citizen@example.com',
  subject: 'Complaint Submitted',
  html: complaintTemplate
});
```

## 🔒 Security Features

✅ **JWT Authentication** - Secure token-based auth  
✅ **Password Hashing** - bcrypt with salt rounds  
✅ **Role-Based Access Control** - Middleware protection  
✅ **Rate Limiting** - 100 requests per 15 minutes  
✅ **Helmet.js** - HTTP security headers  
✅ **CORS** - Configured for frontend domain  
✅ **Input Validation** - Express Validator  
✅ **File Upload Limits** - Max 5MB per file  

## 📊 Sample API Responses

### Success Response
```json
{
  "success": true,
  "message": "Projects retrieved successfully",
  "data": {
    "projects": [...],
    "pagination": {
      "page": 1,
      "limit": 10,
      "total": 47,
      "pages": 5
    }
  }
}
```

### Error Response
```json
{
  "success": false,
  "message": "Validation failed",
  "errors": [
    {
      "field": "email",
      "message": "Please provide a valid email"
    }
  ]
}
```

## 🧪 Testing

### Manual Testing with Postman

1. **Import Collection**: Use the provided Postman collection
2. **Set Environment Variables**:
   - `baseURL`: `http://localhost:5000/api`
   - `token`: (set after login)

### Example Requests

**Get All Projects:**
```bash
curl http://localhost:5000/api/projects
```

**Create Project (Admin):**
```bash
curl -X POST http://localhost:5000/api/projects \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "New Highway Project",
    "department": "Roads & Infrastructure",
    ...
  }'
```

## 📈 Performance Optimization

✅ Database indexing on frequently queried fields  
✅ Pagination for large datasets  
✅ Aggregation pipelines for analytics  
✅ Caching strategy (future enhancement)  
✅ Image optimization via Cloudinary  
✅ Rate limiting to prevent abuse  

## 🚀 Deployment

### Environment Setup

1. **Production Environment Variables**
```env
NODE_ENV=production
MONGODB_URI=mongodb+srv://...
FRONTEND_URL=https://your-frontend.vercel.app
```

2. **Build and Deploy** (Render.com)

```bash
# Render will automatically:
# 1. Install dependencies (npm install)
# 2. Start server (npm start)
```

### Deployment Checklist

- [ ] Environment variables configured
- [ ] MongoDB Atlas connection tested
- [ ] Cloudinary credentials set
- [ ] CORS configured for production URL
- [ ] Rate limiting enabled
- [ ] Error logging configured
- [ ] Email service configured
- [ ] Cron jobs scheduled

## 🐛 Troubleshooting

### MongoDB Connection Issues
```bash
# Check connection string format
mongodb+srv://username:password@cluster.mongodb.net/petms

# Verify IP whitelist in MongoDB Atlas
```

### JWT Token Errors
```javascript
// Ensure JWT_SECRET is set
// Check token expiration (JWT_EXPIRE)
```

### File Upload Failures
```javascript
// Check file size (< 5MB)
// Verify Cloudinary credentials
// Ensure 'uploads' directory exists
```

### GPS Extraction Issues
```javascript
// Photos must have EXIF GPS data
// Use mobile camera (not screenshots)
// Enable location services when taking photos
```

## 📝 Scripts

```json
{
  "scripts": {
    "start": "node src/server.js",
    "dev": "nodemon src/server.js",
    "seed": "node scripts/seed.js"
  }
}
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

MIT License - see LICENSE file for details

---

## 🆘 Support

For issues and questions:
- **GitHub Issues**: [Create an issue](https://github.com/yourusername/petms/issues)
- **Email**: support@petms.example.com

---

<div align="center">

**Built with ⚡ for efficient government monitoring**

[Documentation](https://docs.petms.example.com) · [Report Bug](https://github.com/yourusername/petms/issues) · [API Docs](https://api.petms.example.com/docs)

</div>
